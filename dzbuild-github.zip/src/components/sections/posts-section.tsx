'use client';

import { useState, useEffect } from 'react';
import { useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { translations, Locale } from '@/lib/translations';
import {
  MessageSquare,
  Heart,
  Share2,
  Bookmark,
  Image as ImageIcon,
  Video,
  Link as LinkIcon,
  Send,
  Home,
  Loader2,
  MessageCircle,
  Lightbulb,
  BookOpen,
  Newspaper,
  Megaphone,
  FileText,
  Search,
  ChevronLeft,
  Layers,
} from 'lucide-react';

interface PostsSectionProps {
  onBack?: () => void;
}

// Post categories with icons and colors
const POST_CATEGORIES = [
  { 
    id: 'discussion', 
    icon: MessageCircle, 
    color: 'bg-blue-500',
    names: { ar: 'نقاش', fr: 'Discussion', en: 'Discussion' },
    descriptions: { ar: 'نقاشات وتبادل الخبرات', fr: 'Discussions et partage', en: 'Discussions and sharing' }
  },
  { 
    id: 'advice', 
    icon: Lightbulb, 
    color: 'bg-yellow-500',
    names: { ar: 'نصيحة', fr: 'Conseil', en: 'Advice' },
    descriptions: { ar: 'استشر المهندسين الخبراء', fr: 'Consultez les experts', en: 'Consult experts' }
  },
  { 
    id: 'experience', 
    icon: BookOpen, 
    color: 'bg-purple-500',
    names: { ar: 'تجربة', fr: 'Expérience', en: 'Experience' },
    descriptions: { ar: 'شارك تجربتك الهندسية', fr: 'Partagez votre expérience', en: 'Share your experience' }
  },
  { 
    id: 'news', 
    icon: Newspaper, 
    color: 'bg-green-500',
    names: { ar: 'أخبار', fr: 'Actualités', en: 'News' },
    descriptions: { ar: 'أخبار ومستجدات القطاع', fr: 'Actualités du secteur', en: 'Sector news' }
  },
  { 
    id: 'announcement', 
    icon: Megaphone, 
    color: 'bg-orange-500',
    names: { ar: 'إعلان', fr: 'Annonce', en: 'Announcement' },
    descriptions: { ar: 'إعلانات هندسية', fr: 'Annonces techniques', en: 'Technical announcements' }
  },
  { 
    id: 'other', 
    icon: FileText, 
    color: 'bg-gray-500',
    names: { ar: 'أخرى', fr: 'Autre', en: 'Other' },
    descriptions: { ar: 'مواضيع متنوعة', fr: 'Sujets divers', en: 'Various topics' }
  },
];

interface Post {
  id: string;
  title?: string;
  content: string;
  images?: string;
  videos?: string;
  category?: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
    role: string;
  };
  likeCount: number;
  commentCount: number;
  viewCount: number;
  isLiked?: boolean;
  createdAt: string;
}

interface Comment {
  id: string;
  content: string;
  author: {
    id: string;
    name: string;
    avatar?: string;
  };
  createdAt: string;
}

const roleColors: Record<string, string> = {
  CIVIL_ENGINEER: 'bg-blue-500',
  CONTRACTOR: 'bg-orange-500',
  ENGINEERING_OFFICE: 'bg-purple-500',
  CRAFTSMAN: 'bg-amber-500',
  CONSTRUCTION_COMPANY: 'bg-green-500',
  STORE_FACTORY: 'bg-cyan-500',
  NORMAL_USER: 'bg-gray-500',
  ADMIN: 'bg-red-500',
};

const roleLabelsAr: Record<string, string> = {
  CIVIL_ENGINEER: 'مهندس مدني',
  CONTRACTOR: 'مقاول',
  ENGINEERING_OFFICE: 'مكتب دراسات',
  CRAFTSMAN: 'حرفي',
  CONSTRUCTION_COMPANY: 'شركة بناء',
  STORE_FACTORY: 'متجر / مصنع',
  NORMAL_USER: 'مستخدم',
  ADMIN: 'مدير',
};

export function PostsSection({ onBack }: PostsSectionProps) {
  const { user, locale } = useAppStore();
  const isRTL = locale === 'ar';
  const t = translations.postsSection;
  
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [newPostContent, setNewPostContent] = useState('');
  const [posting, setPosting] = useState(false);
  const [selectedPost, setSelectedPost] = useState<Post | null>(null);
  const [comments, setComments] = useState<Comment[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newComment, setNewComment] = useState('');

  // Fetch posts from API
  useEffect(() => {
    if (selectedCategory !== null) {
      fetchPosts();
    }
  }, [selectedCategory]);

  const fetchPosts = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory && selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }
      
      const res = await fetch(`/api/posts?${params.toString()}`);
      if (res.ok) {
        const data = await res.json();
        setPosts(data.posts || []);
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter posts by search
  const filteredPosts = posts.filter(post => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        post.title?.toLowerCase().includes(query) ||
        post.content?.toLowerCase().includes(query) ||
        post.author?.name?.toLowerCase().includes(query)
      );
    }
    return true;
  });

  // Get category info
  const getCategoryInfo = (categoryId: string) => {
    return POST_CATEGORIES.find(c => c.id === categoryId) || POST_CATEGORIES[5];
  };

  const handleCreatePost = async () => {
    if (!newPostContent.trim() || !user) return;

    setPosting(true);
    try {
      const res = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          content: newPostContent.trim(),
          category: selectedCategory !== 'all' ? selectedCategory : 'discussion'
        }),
      });
      
      if (res.ok) {
        const data = await res.json();
        setPosts([data.post, ...posts]);
        setNewPostContent('');
      }
    } catch (error) {
      console.error('Error creating post:', error);
    } finally {
      setPosting(false);
    }
  };

  const handleLike = async (postId: string) => {
    if (!user) return;
    
    try {
      const res = await fetch('/api/posts/likes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId }),
      });
      
      if (res.ok) {
        setPosts(posts.map(post => {
          if (post.id === postId) {
            return {
              ...post,
              isLiked: !post.isLiked,
              likeCount: post.isLiked ? post.likeCount - 1 : post.likeCount + 1,
            };
          }
          return post;
        }));
      }
    } catch (error) {
      console.error('Error liking post:', error);
    }
  };

  const openComments = async (post: Post) => {
    setSelectedPost(post);
    setLoadingComments(true);
    
    try {
      const res = await fetch(`/api/posts/comments?postId=${post.id}`);
      if (res.ok) {
        const data = await res.json();
        setComments(data.comments || []);
      }
    } catch (error) {
      console.error('Error fetching comments:', error);
    } finally {
      setLoadingComments(false);
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diff = now.getTime() - date.getTime();
    
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 60) {
      return locale === 'ar' ? `منذ ${minutes} دقيقة` : locale === 'fr' ? `Il y a ${minutes} min` : `${minutes}m ago`;
    }
    if (hours < 24) {
      return locale === 'ar' ? `منذ ${hours} ساعة` : locale === 'fr' ? `Il y a ${hours}h` : `${hours}h ago`;
    }
    return locale === 'ar' ? `منذ ${days} يوم` : locale === 'fr' ? `Il y a ${days}j` : `${days}d ago`;
  };

  const getInitials = (name: string) => {
    return name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || '?';
  };

  // Category Selection View
  if (selectedCategory === null) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <MessageSquare className="h-6 w-6 text-primary" />
              {t.title[locale]}
            </h1>
            <p className="text-muted-foreground">
              {t.subtitle[locale]}
            </p>
          </div>
          {onBack && (
            <Button variant="default" onClick={onBack} className="gap-2">
              <Home className="h-4 w-4" />
              {translations.home[locale]}
            </Button>
          )}
        </div>

        {/* Category Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* All Posts Card */}
          <Card 
            className="cursor-pointer hover:shadow-lg transition-all hover:border-primary"
            onClick={() => setSelectedCategory('all')}
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl text-white bg-primary">
                  <Layers className="h-6 w-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">
                    {t.allPosts[locale]}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {t.allPostsDesc[locale]}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Category Cards */}
          {POST_CATEGORIES.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card 
                key={category.id}
                className="cursor-pointer hover:shadow-lg transition-all hover:border-primary"
                onClick={() => setSelectedCategory(category.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={cn('p-3 rounded-xl text-white', category.color)}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg">
                        {category.names[locale as 'ar' | 'fr' | 'en'] || category.names.en}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {category.descriptions[locale as 'ar' | 'fr' | 'en'] || category.descriptions.en}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    );
  }

  // Posts List View
  const currentCategory = POST_CATEGORIES.find(c => c.id === selectedCategory);
  const CategoryIcon = currentCategory?.icon || MessageSquare;

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <div className="flex gap-2">
        <Button variant="outline" onClick={() => setSelectedCategory(null)} className="gap-2">
          <ChevronLeft className={isRTL ? "rotate-180" : ""} />
          {translations.backToList[locale]}
        </Button>
        {onBack && (
          <Button variant="default" onClick={onBack} className="gap-2">
            <Home className="h-4 w-4" />
            {translations.home[locale]}
          </Button>
        )}
      </div>

      {/* Category Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className={cn('p-2 rounded-lg text-white', currentCategory?.color || 'bg-primary')}>
              <CategoryIcon className="h-5 w-5" />
            </div>
            <div>
              <CardTitle>
                {selectedCategory === 'all' 
                  ? t.allPosts[locale] 
                  : currentCategory?.names[locale as 'ar' | 'fr' | 'en'] || currentCategory?.names.en
                }
              </CardTitle>
              <CardDescription>
                {filteredPosts.length} {locale === 'ar' ? 'منشور' : locale === 'fr' ? 'publications' : 'posts'}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", isRTL ? "right-3" : "left-3")} />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.search[locale]}
              className={isRTL ? "pr-10" : "pl-10"}
            />
          </div>
        </CardContent>
      </Card>

      {/* Create Post */}
      {user && (
        <Card>
          <CardContent className="p-4">
            <div className="flex gap-3">
              <Avatar className="h-10 w-10 shrink-0">
                <AvatarImage src={user?.avatar} />
                <AvatarFallback className={cn('text-white text-sm', roleColors[user?.role || 'NORMAL_USER'])}>
                  {user ? getInitials(user.name) : '?'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-3">
                <textarea
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  placeholder={locale === 'ar' ? 'أنشئ منشوراً...' : 'Créer une publication...'}
                  className="w-full min-h-[80px] resize-none border-0 bg-muted/50 rounded-md p-3 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                />
                <div className="flex items-center justify-between">
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" className="text-muted-foreground h-8 w-8 p-0">
                      <ImageIcon className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-muted-foreground h-8 w-8 p-0">
                      <Video className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" className="text-muted-foreground h-8 w-8 p-0">
                      <LinkIcon className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button 
                    size="sm" 
                    onClick={handleCreatePost}
                    disabled={!newPostContent.trim() || posting}
                    className="gap-2"
                  >
                    {posting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <>
                        <Send className="h-4 w-4" />
                        {locale === 'ar' ? 'نشر' : 'Publier'}
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Loading State */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filteredPosts.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <MessageSquare className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">{t.noPosts[locale]}</p>
            <p className="text-sm text-muted-foreground mt-2">
              {locale === 'ar' ? 'كن أول من ينشر!' : 'Soyez le premier à publier!'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredPosts.map((post) => {
            const categoryInfo = getCategoryInfo(post.category || 'other');
            const IconComponent = categoryInfo.icon;
            
            return (
              <Card 
                key={post.id} 
                className="overflow-hidden hover:shadow-lg transition-all cursor-pointer"
                onClick={() => openComments(post)}
              >
                <CardContent className="p-4">
                  {/* Post Header */}
                  <div className="flex items-start gap-3 mb-3">
                    <Avatar className="h-10 w-10 shrink-0">
                      <AvatarImage src={post.author.avatar} />
                      <AvatarFallback className={cn('text-white text-sm', roleColors[post.author.role])}>
                        {getInitials(post.author.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold truncate">{post.author.name}</span>
                        <Badge variant="secondary" className="text-xs shrink-0">
                          {roleLabelsAr[post.author.role] || post.author.role}
                        </Badge>
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {formatTimeAgo(post.createdAt)}
                      </span>
                    </div>
                    <div className={cn('p-2 rounded-lg text-white shrink-0', categoryInfo.color)}>
                      <IconComponent className="h-4 w-4" />
                    </div>
                  </div>

                  {/* Post Content */}
                  <p className="whitespace-pre-wrap mb-3 text-sm leading-relaxed">{post.content}</p>

                  {/* Post Images */}
                  {post.images && (
                    <div className="mb-3 rounded-lg overflow-hidden bg-muted">
                      <img 
                        src={post.images} 
                        alt="" 
                        className="w-full h-auto max-h-96 object-contain"
                      />
                    </div>
                  )}

                  {/* Post Stats */}
                  <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3 py-2 border-y">
                    <span className="flex items-center gap-1">
                      <Heart className="h-3.5 w-3.5" />
                      {post.likeCount}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-3.5 w-3.5" />
                      {post.commentCount}
                    </span>
                    <span className="flex items-center gap-1">
                      {post.viewCount} {locale === 'ar' ? 'مشاهدة' : 'vues'}
                    </span>
                  </div>

                  {/* Post Actions */}
                  <div className="flex items-center justify-between">
                    <div className="flex gap-1">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className={cn("gap-1.5 h-8", post.isLiked && "text-pink-500")}
                        onClick={(e) => { e.stopPropagation(); handleLike(post.id); }}
                      >
                        <Heart className={cn("h-4 w-4", post.isLiked && "fill-current")} />
                        <span className="hidden sm:inline text-xs">
                          {locale === 'ar' ? 'إعجاب' : "J'aime"}
                        </span>
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-1.5 h-8">
                        <MessageCircle className="h-4 w-4" />
                        <span className="hidden sm:inline text-xs">
                          {locale === 'ar' ? 'تعليق' : 'Commenter'}
                        </span>
                      </Button>
                      <Button variant="ghost" size="sm" className="gap-1.5 h-8">
                        <Share2 className="h-4 w-4" />
                        <span className="hidden sm:inline text-xs">
                          {locale === 'ar' ? 'مشاركة' : 'Partager'}
                        </span>
                      </Button>
                    </div>
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Bookmark className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Comments Dialog */}
      <Dialog open={!!selectedPost} onOpenChange={() => setSelectedPost(null)}>
        <DialogContent className="max-w-lg max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5 text-primary" />
              {locale === 'ar' ? 'التعليقات' : 'Commentaires'}
            </DialogTitle>
          </DialogHeader>
          
          <ScrollArea className="flex-1 -mx-6 px-6">
            {loadingComments ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin" />
              </div>
            ) : comments.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                {locale === 'ar' ? 'لا توجد تعليقات' : 'Aucun commentaire'}
              </div>
            ) : (
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="flex gap-3">
                    <Avatar className="h-8 w-8 shrink-0">
                      <AvatarFallback className="text-xs">
                        {getInitials(comment.author.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 bg-muted/50 rounded-xl p-3">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{comment.author.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatTimeAgo(comment.createdAt)}
                        </span>
                      </div>
                      <p className="text-sm mt-1">{comment.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
          
          {/* Add Comment */}
          {user && (
            <div className="flex gap-2 pt-4 border-t">
              <Input
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder={locale === 'ar' ? 'أضف تعليقاً...' : 'Ajouter un commentaire...'}
                className="flex-1"
              />
              <Button size="sm" disabled={!newComment.trim()}>
                <Send className="h-4 w-4" />
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default PostsSection;
