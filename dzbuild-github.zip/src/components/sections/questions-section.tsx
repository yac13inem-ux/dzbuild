'use client';

import { useState, useEffect } from 'react';
import { useAppStore } from '@/stores/app-store';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { translations, Locale } from '@/lib/translations';
import {
  HelpCircle,
  Home,
  ChevronLeft,
  Loader2,
  MessageCircle,
  CheckCircle,
  Pin,
  Plus,
  Clock,
  Send,
  ThumbsUp,
  Eye,
  Building2,
  Cylinder,
  Layers,
  MapPin,
  Search,
} from 'lucide-react';

interface QuestionsSectionProps {
  onBack?: () => void;
}

// Question categories with icons and colors
const QUESTION_CATEGORIES = [
  { 
    id: 'concrete', 
    icon: Layers, 
    color: 'bg-blue-500',
    names: { ar: 'خرسانة', fr: 'Béton', en: 'Concrete' },
    descriptions: { ar: 'أسئلة حول الخرسانة والصب', fr: 'Questions sur le béton', en: 'Concrete questions' }
  },
  { 
    id: 'reinforcement', 
    icon: Cylinder, 
    color: 'bg-slate-600',
    names: { ar: 'حديد التسليح', fr: 'Armature', en: 'Reinforcement' },
    descriptions: { ar: 'أسئلة حول التسليح', fr: 'Questions sur le ferraillage', en: 'Reinforcement questions' }
  },
  { 
    id: 'foundations', 
    icon: Building2, 
    color: 'bg-stone-600',
    names: { ar: 'الأساسات', fr: 'Fondations', en: 'Foundations' },
    descriptions: { ar: 'أسئلة حول الأساسات', fr: 'Questions sur les fondations', en: 'Foundation questions' }
  },
  { 
    id: 'site', 
    icon: MapPin, 
    color: 'bg-orange-500',
    names: { ar: 'الموقع', fr: 'Chantier', en: 'Site' },
    descriptions: { ar: 'أسئلة حول إدارة الموقع', fr: 'Questions sur le chantier', en: 'Site management questions' }
  },
];

interface Question {
  id: string;
  title: string;
  content?: string;
  category: string;
  images?: string[];
  author_name?: string;
  author_role?: string;
  answers_count: number;
  votes_count: number;
  views_count: number;
  is_solved: boolean;
  is_pinned: boolean;
  created_at: string;
}

export function QuestionsSection({ onBack }: QuestionsSectionProps) {
  const { locale, isLoggedIn } = useAppStore();
  const isRTL = locale === 'ar';
  const t = translations.questionsSection;
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedQuestion, setSelectedQuestion] = useState<Question | null>(null);
  const [showAskDialog, setShowAskDialog] = useState(false);
  const [newQuestion, setNewQuestion] = useState({
    title: '',
    content: '',
    category: '',
  });

  // Fetch questions
  useEffect(() => {
    if (selectedCategory !== null) {
      fetchQuestions();
    }
  }, [selectedCategory]);

  const fetchQuestions = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory && selectedCategory !== 'all') {
        params.append('category', selectedCategory);
      }
      
      const res = await fetch(`/api/questions?${params.toString()}`);
      const data = await res.json();
      setQuestions(data.questions || []);
    } catch (error) {
      console.error('Error fetching questions:', error);
    } finally {
      setLoading(false);
    }
  };

  // Filter questions by search
  const filteredQuestions = questions.filter(q => {
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        q.title?.toLowerCase().includes(query) ||
        q.content?.toLowerCase().includes(query)
      );
    }
    return true;
  });

  // Get category info
  const getCategoryInfo = (categoryId: string) => {
    return QUESTION_CATEGORIES.find(c => c.id === categoryId);
  };

  // Get time ago
  const getTimeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    if (hours < 24) return isRTL ? `${hours} ساعة` : `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return isRTL ? `${days} يوم` : `${days}j`;
    const weeks = Math.floor(days / 7);
    return isRTL ? `${weeks} أسبوع` : `${weeks}sem`;
  };

  // Handle ask question
  const handleAskQuestion = async () => {
    if (!newQuestion.title || !newQuestion.category) return;
    
    try {
      const res = await fetch('/api/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newQuestion),
      });
      
      if (res.ok) {
        setShowAskDialog(false);
        setNewQuestion({ title: '', content: '', category: '' });
        fetchQuestions();
      }
    } catch (error) {
      console.error('Error asking question:', error);
    }
  };

  // Question Detail View
  if (selectedQuestion) {
    const categoryInfo = getCategoryInfo(selectedQuestion.category);
    const CategoryIcon = categoryInfo?.icon || HelpCircle;
    
    return (
      <div className="space-y-6">
        {/* Back Button */}
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setSelectedQuestion(null)} className="gap-2">
            <ChevronLeft className={isRTL ? "rotate-180" : ""} />
            {translations.backToList[locale]}
          </Button>
          {onBack && (
            <Button variant="default" onClick={onBack} className="gap-2">
              <Home className="h-4 w-4" />
              {translations.home[locale]}
            </Button>
          )}
        </div>
        
        {/* Question Header */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className={cn('p-2 rounded-lg text-white', categoryInfo?.color || 'bg-primary')}>
                <CategoryIcon className="h-5 w-5" />
              </div>
              <div>
                <CardTitle className="text-xl">{selectedQuestion.title}</CardTitle>
                <CardDescription className="flex items-center gap-3 mt-1">
                  <span>{selectedQuestion.author_name || (isRTL ? 'مجهول' : 'Anonyme')}</span>
                  <span>•</span>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {getTimeAgo(selectedQuestion.created_at)}
                  </div>
                </CardDescription>
              </div>
            </div>
          </CardHeader>
        </Card>

        {/* Status Badges */}
        <div className="flex gap-2">
          {selectedQuestion.is_pinned && (
            <Badge className="bg-yellow-500 text-white">
              <Pin className="h-3 w-3 me-1" />
              {isRTL ? 'مثبت' : 'Épinglée'}
            </Badge>
          )}
          {selectedQuestion.is_solved && (
            <Badge className="bg-green-500 text-white">
              <CheckCircle className="h-3 w-3 me-1" />
              {isRTL ? 'تم الحل' : 'Résolue'}
            </Badge>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <ThumbsUp className="h-5 w-5 mx-auto mb-2 text-muted-foreground" />
              <p className="font-bold text-lg">{selectedQuestion.votes_count || 0}</p>
              <p className="text-xs text-muted-foreground">{isRTL ? 'تصويت' : 'votes'}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <MessageCircle className="h-5 w-5 mx-auto mb-2 text-muted-foreground" />
              <p className="font-bold text-lg">{selectedQuestion.answers_count || 0}</p>
              <p className="text-xs text-muted-foreground">{isRTL ? 'إجابة' : 'réponses'}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Eye className="h-5 w-5 mx-auto mb-2 text-muted-foreground" />
              <p className="font-bold text-lg">{selectedQuestion.views_count || 0}</p>
              <p className="text-xs text-muted-foreground">{isRTL ? 'مشاهدة' : 'vues'}</p>
            </CardContent>
          </Card>
        </div>

        {/* Question Content */}
        {selectedQuestion.content && (
          <Card>
            <CardContent className="p-6">
              <p className="text-muted-foreground leading-relaxed whitespace-pre-wrap">
                {selectedQuestion.content}
              </p>
            </CardContent>
          </Card>
        )}

        {/* Answer Input */}
        <Card>
          <CardContent className="p-4 space-y-4">
            <h3 className="font-semibold">
              {isRTL ? 'أضف إجابتك' : 'Ajouter votre réponse'}
            </h3>
            <Textarea 
              placeholder={isRTL ? "اكتب إجابتك هنا..." : "Écrivez votre réponse ici..."}
              className="min-h-[100px]"
            />
            <Button className="gap-2">
              <Send className="h-4 w-4" />
              {isRTL ? 'إرسال الإجابة' : 'Envoyer'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Category Selection View
  if (selectedCategory === null) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <HelpCircle className="h-6 w-6 text-primary" />
              {t.title[locale]}
            </h1>
            <p className="text-muted-foreground">
              {t.subtitle[locale]}
            </p>
          </div>
          {onBack && (
            <Button variant="default" onClick={onBack} className="gap-2">
              <Home className="h-4 w-4" />
              {translations.home[locale]}
            </Button>
          )}
        </div>

        {/* Category Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* All Questions Card */}
          <Card 
            className="cursor-pointer hover:shadow-lg transition-all hover:border-primary"
            onClick={() => setSelectedCategory('all')}
          >
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="p-3 rounded-xl text-white bg-primary">
                  <HelpCircle className="h-6 w-6" />
                </div>
                <div className="flex-1">
                  <h3 className="font-bold text-lg">
                    {t.allQuestions[locale]}
                  </h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {t.allQuestionsDesc[locale]}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Category Cards */}
          {QUESTION_CATEGORIES.map((category) => {
            const IconComponent = category.icon;
            return (
              <Card 
                key={category.id}
                className="cursor-pointer hover:shadow-lg transition-all hover:border-primary"
                onClick={() => setSelectedCategory(category.id)}
              >
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={cn('p-3 rounded-xl text-white', category.color)}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg">
                        {category.names[locale as 'ar' | 'fr' | 'en'] || category.names.en}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {category.descriptions[locale as 'ar' | 'fr' | 'en'] || category.descriptions.en}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    );
  }

  // Questions List View
  const currentCategory = QUESTION_CATEGORIES.find(c => c.id === selectedCategory);
  const CategoryIcon = currentCategory?.icon || HelpCircle;

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <div className="flex gap-2">
        <Button variant="outline" onClick={() => setSelectedCategory(null)} className="gap-2">
          <ChevronLeft className={isRTL ? "rotate-180" : ""} />
          {translations.backToList[locale]}
        </Button>
        {onBack && (
          <Button variant="default" onClick={onBack} className="gap-2">
            <Home className="h-4 w-4" />
            {translations.home[locale]}
          </Button>
        )}
      </div>

      {/* Category Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className={cn('p-2 rounded-lg text-white', currentCategory?.color || 'bg-primary')}>
                <CategoryIcon className="h-5 w-5" />
              </div>
              <div>
                <CardTitle>
                  {selectedCategory === 'all' 
                    ? t.allQuestions[locale] 
                    : currentCategory?.names[locale as 'ar' | 'fr' | 'en'] || currentCategory?.names.en
                  }
                </CardTitle>
                <CardDescription>
                  {filteredQuestions.length} {isRTL ? 'سؤال' : 'questions'}
                </CardDescription>
              </div>
            </div>
            <Dialog open={showAskDialog} onOpenChange={setShowAskDialog}>
              <DialogTrigger asChild>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  {isRTL ? 'اطرح سؤالاً' : 'Poser'}
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg">
                <DialogHeader>
                  <DialogTitle>{isRTL ? 'طرح سؤال جديد' : 'Nouvelle question'}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <label className="text-sm font-medium mb-1 block">
                      {isRTL ? 'عنوان السؤال' : 'Titre'}
                    </label>
                    <Input
                      value={newQuestion.title}
                      onChange={(e) => setNewQuestion({...newQuestion, title: e.target.value})}
                      placeholder={isRTL ? "مثال: كيف أحسب نسبة الخلطة؟" : "Ex: Comment calculer...?"}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">
                      {isRTL ? 'القسم' : 'Catégorie'}
                    </label>
                    <select
                      value={newQuestion.category}
                      onChange={(e) => setNewQuestion({...newQuestion, category: e.target.value})}
                      className="w-full h-10 rounded-md border border-input bg-background px-3"
                    >
                      <option value="">{isRTL ? "اختر القسم" : "Choisir"}</option>
                      {QUESTION_CATEGORIES.map(cat => (
                        <option key={cat.id} value={cat.id}>
                          {cat.names[locale as 'ar' | 'fr' | 'en'] || cat.names.en}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-1 block">
                      {isRTL ? 'تفاصيل السؤال' : 'Détails'}
                    </label>
                    <Textarea
                      value={newQuestion.content}
                      onChange={(e) => setNewQuestion({...newQuestion, content: e.target.value})}
                      placeholder={isRTL ? "اشرح مشكلتك..." : "Expliquez votre problème..."}
                      className="min-h-[150px]"
                    />
                  </div>
                  <Button className="w-full gap-2" onClick={handleAskQuestion}>
                    <Send className="h-4 w-4" />
                    {isRTL ? 'نشر السؤال' : 'Publier'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", isRTL ? "right-3" : "left-3")} />
            <Input
              placeholder={t.search[locale]}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={isRTL ? "pr-10" : "pl-10"}
            />
          </div>
        </CardContent>
      </Card>

      {/* Loading State */}
      {loading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : filteredQuestions.length === 0 ? (
        <Card>
          <CardContent className="p-12 text-center">
            <HelpCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <p className="text-muted-foreground">{t.noQuestions[locale]}</p>
            <p className="text-sm text-muted-foreground mt-2">
              {isRTL ? 'كن أول من يطرح سؤالاً!' : 'Soyez le premier à poser une question!'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredQuestions.map((question) => {
            const category = getCategoryInfo(question.category);
            const IconComponent = category?.icon || HelpCircle;
            
            return (
              <Card 
                key={question.id} 
                className="overflow-hidden hover:shadow-lg transition-all cursor-pointer"
                onClick={() => setSelectedQuestion(question)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    {/* Vote count */}
                    <div className="flex flex-col items-center gap-1 shrink-0">
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0" onClick={(e) => e.stopPropagation()}>
                        <ThumbsUp className="h-4 w-4" />
                      </Button>
                      <span className="font-bold text-lg">{question.votes_count || 0}</span>
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        {question.is_pinned && (
                          <Pin className="h-4 w-4 text-yellow-500" />
                        )}
                        {question.is_solved && (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        )}
                      </div>
                      <h3 className="font-semibold text-lg truncate">{question.title}</h3>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {category?.names[locale as 'ar' | 'fr' | 'en'] || category?.names.en}
                        </Badge>
                        <div className="flex items-center gap-1">
                          <MessageCircle className="h-3 w-3" />
                          <span>{question.answers_count || 0}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          <span>{question.views_count || 0}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          <span>{getTimeAgo(question.created_at)}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

export default QuestionsSection;
