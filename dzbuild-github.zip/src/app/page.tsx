'use client';

import { useState, useEffect } from 'react';
import { useAppStore } from '@/stores/app-store';
import { AuthDialog } from '@/components/shared/auth-dialog';
import { AppHeader } from '@/components/layout/app-header';
import { AdminDashboard } from '@/components/admin/admin-dashboard';
import { AdCarousel, AdPopup } from '@/components/ads/ad-banner';
import { UserDashboard } from '@/components/user/user-dashboard';
import { UserProfile } from '@/components/user/user-profile';
import { UserSettings } from '@/components/user/user-settings';
import { NotificationsCenter } from '@/components/user/notifications-center';
import { MessagesCenter } from '@/components/user/messages-center';
import { PostsSection } from '@/components/sections/posts-section';
import { CompaniesSection } from '@/components/sections/companies-section';
import { CraftsmenSection } from '@/components/sections/craftsmen-section';
import { MarketSection } from '@/components/sections/market-section';
import { QuestionsSection } from '@/components/sections/questions-section';
import { JobsSection } from '@/components/sections/jobs-section';
import { CalculatorSection } from '@/components/sections/calculator-section';
import { LibrarySection } from '@/components/sections/library-section';
import { ProjectsSection } from '@/components/sections/projects-section';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { cn } from '@/lib/utils';
import { translations } from '@/lib/translations';
import {
  Building2,
  HelpCircle,
  Calculator,
  Briefcase,
  BookOpen,
  FolderKanban,
  Users,
  Wrench,
  ShoppingCart,
  LayoutDashboard,
  User,
  Settings,
  Bell,
  MessageSquare,
  Home as HomeIcon,
  AlertCircle,
  X,
} from 'lucide-react';

const roleColors: Record<string, string> = {
  CIVIL_ENGINEER: 'bg-blue-500',
  CONTRACTOR: 'bg-orange-500',
  ENGINEERING_OFFICE: 'bg-purple-500',
  CRAFTSMAN: 'bg-amber-500',
  CONSTRUCTION_COMPANY: 'bg-green-500',
  STORE_FACTORY: 'bg-cyan-500',
  NORMAL_USER: 'bg-gray-500',
  ADMIN: 'bg-red-500',
};

type ActiveView = 
  | 'landing' 
  | 'dashboard'
  | 'profile'
  | 'settings'
  | 'notifications'
  | 'messages'
  | 'posts' 
  | 'companies' 
  | 'craftsmen'
  | 'market'
  | 'questions' 
  | 'calculator' 
  | 'jobs' 
  | 'library' 
  | 'projects';

export default function Home() {
  const { user, locale, isLoggedIn } = useAppStore();
  const [authOpen, setAuthOpen] = useState(false);
  const [activeView, setActiveView] = useState<ActiveView>('landing');
  const [oauthError, setOauthError] = useState<string | null>(null);
  const [stats, setStats] = useState({
    artisans: 0,
    engineers: 0,
    companies: 0,
    projects: 0,
  });
  const isRTL = locale === 'ar';

  // Handle OAuth errors from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const error = params.get('error');
    if (error) {
      let errorMessage = error;
      if (error.includes('provider is not enabled')) {
        errorMessage = locale === 'ar' 
          ? 'تسجيل الدخول بـ Google غير مفعل حالياً. يرجى استخدام التسجيل بالإيميل.'
          : locale === 'fr'
          ? "La connexion Google n'est pas encore activée. Veuillez utiliser l'inscription par email."
          : 'Google sign-in is not enabled yet. Please use email registration.';
      } else if (error.includes('oauth_cancelled')) {
        errorMessage = locale === 'ar' 
          ? 'تم إلغاء تسجيل الدخول'
          : locale === 'fr'
          ? 'Connexion annulée'
          : 'Sign-in was cancelled';
      }
      setTimeout(() => {
        setOauthError(errorMessage);
        setAuthOpen(true);
      }, 0);
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [locale]);

  // Fetch real stats from API
  useEffect(() => {
    const fetchStats = async () => {
      try {
        const res = await fetch('/api/admin/stats');
        const data = await res.json();
        if (data.stats) {
          setStats({
            artisans: data.stats.craftsmenCount || 0,
            engineers: data.stats.engineersCount || 0,
            companies: data.stats.companiesCount || 0,
            projects: data.stats.projectsCount || 0,
          });
        }
      } catch (error) {
        console.error('Error fetching stats:', error);
      }
    };
    fetchStats();
  }, []);

  // Admin Dashboard
  if (isLoggedIn && user?.role === 'ADMIN') {
    return <AdminDashboard />;
  }

  const handleNavClick = (view: ActiveView) => {
    setActiveView(view);
  };

  // All 9 sections available for users
  const userSectionNavItems = [
    { icon: Users, key: 'posts', view: 'posts' as ActiveView, color: 'bg-pink-500' },
    { icon: Building2, key: 'companies', view: 'companies' as ActiveView, color: 'bg-green-500' },
    { icon: Wrench, key: 'craftsmen', view: 'craftsmen' as ActiveView, color: 'bg-amber-500' },
    { icon: ShoppingCart, key: 'market', view: 'market' as ActiveView, color: 'bg-cyan-500' },
    { icon: HelpCircle, key: 'questions', view: 'questions' as ActiveView, color: 'bg-blue-500' },
    { icon: Calculator, key: 'calculator', view: 'calculator' as ActiveView, color: 'bg-purple-500' },
    { icon: Briefcase, key: 'jobs', view: 'jobs' as ActiveView, color: 'bg-orange-500' },
    { icon: BookOpen, key: 'library', view: 'library' as ActiveView, color: 'bg-red-500' },
    { icon: FolderKanban, key: 'projects', view: 'projects' as ActiveView, color: 'bg-teal-500' },
  ];

  // All 9 navigation items for landing page
  const allSectionNavItems = [
    { icon: Users, key: 'posts', view: 'posts' as ActiveView, color: 'bg-pink-500' },
    { icon: Building2, key: 'companies', view: 'companies' as ActiveView, color: 'bg-green-500' },
    { icon: Wrench, key: 'craftsmen', view: 'craftsmen' as ActiveView, color: 'bg-amber-500' },
    { icon: ShoppingCart, key: 'market', view: 'market' as ActiveView, color: 'bg-cyan-500' },
    { icon: HelpCircle, key: 'questions', view: 'questions' as ActiveView, color: 'bg-blue-500' },
    { icon: Calculator, key: 'calculator', view: 'calculator' as ActiveView, color: 'bg-purple-500' },
    { icon: Briefcase, key: 'jobs', view: 'jobs' as ActiveView, color: 'bg-orange-500' },
    { icon: BookOpen, key: 'library', view: 'library' as ActiveView, color: 'bg-red-500' },
    { icon: FolderKanban, key: 'projects', view: 'projects' as ActiveView, color: 'bg-teal-500' },
  ];

  // Render common layout wrapper
  const renderLayout = (children: React.ReactNode, maxWidth = 'max-w-6xl') => (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-muted">
      <AppHeader 
        onAuthClick={() => setAuthOpen(true)} 
        onNavigate={handleNavClick}
        activeView={activeView}
      />
      <main className="flex-1 container mx-auto px-4 py-6">
        {/* Quick Navigation for logged in users */}
        {isLoggedIn && (
          <div className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide">
            {/* Home Button - Always visible */}
            <Button
              variant="outline"
              size="sm"
              className="shrink-0 gap-2 bg-primary/10 border-primary/30 hover:bg-primary/20"
              onClick={() => handleNavClick('landing')}
            >
              <HomeIcon className="h-4 w-4" />
              <span className="hidden sm:inline">{locale === 'ar' ? 'الرئيسية' : locale === 'fr' ? 'Accueil' : 'Home'}</span>
            </Button>
            
            <div className="w-px bg-border mx-1" />
            
            {/* User Navigation */}
            <Button
              variant={activeView === 'dashboard' ? 'default' : 'outline'}
              size="sm"
              className="shrink-0 gap-2"
              onClick={() => handleNavClick('dashboard')}
            >
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">{locale === 'ar' ? 'لوحة التحكم' : locale === 'fr' ? 'Tableau de bord' : 'Dashboard'}</span>
            </Button>
            <Button
              variant={activeView === 'profile' ? 'default' : 'outline'}
              size="sm"
              className="shrink-0 gap-2"
              onClick={() => handleNavClick('profile')}
            >
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">{locale === 'ar' ? 'الملف الشخصي' : locale === 'fr' ? 'Profil' : 'Profile'}</span>
            </Button>
            <Button
              variant={activeView === 'messages' ? 'default' : 'outline'}
              size="sm"
              className="shrink-0 gap-2"
              onClick={() => handleNavClick('messages')}
            >
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">{locale === 'ar' ? 'الرسائل' : locale === 'fr' ? 'Messages' : 'Messages'}</span>
            </Button>
            <Button
              variant={activeView === 'notifications' ? 'default' : 'outline'}
              size="sm"
              className="shrink-0 gap-2"
              onClick={() => handleNavClick('notifications')}
            >
              <Bell className="h-4 w-4" />
              <span className="hidden sm:inline">{locale === 'ar' ? 'الإشعارات' : locale === 'fr' ? 'Notifications' : 'Notifications'}</span>
            </Button>
            <Button
              variant={activeView === 'settings' ? 'default' : 'outline'}
              size="sm"
              className="shrink-0 gap-2"
              onClick={() => handleNavClick('settings')}
            >
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">{locale === 'ar' ? 'الإعدادات' : locale === 'fr' ? 'Paramètres' : 'Settings'}</span>
            </Button>
            <div className="w-px bg-border mx-1" />
            {/* Content Navigation - Only user-accessible sections */}
            {userSectionNavItems.map((item, i) => (
              <Button 
                key={i} 
                variant={activeView === item.view ? 'default' : 'outline'}
                size="sm"
                className="shrink-0 gap-2"
                onClick={() => handleNavClick(item.view)}
              >
                <item.icon className="h-4 w-4" />
                <span className="hidden sm:inline">{translations.features[item.key as keyof typeof translations.features]?.[locale] || item.key}</span>
              </Button>
            ))}
          </div>
        )}
        <div className={maxWidth}>
          {children}
        </div>
      </main>
      <footer className="mt-auto p-4 text-center text-muted-foreground text-sm border-t">
        © 2024 DzBuild - {translations.allRightsReserved[locale]}
      </footer>
      {/* Only show AuthDialog when user is NOT logged in */}
      {!isLoggedIn && <AuthDialog open={authOpen} onOpenChange={(v) => { if (!v) setOauthError(null); setAuthOpen(v); }} externalError={oauthError} />}
      <AdPopup />
    </div>
  );

  // Dashboard View
  if (activeView === 'dashboard') {
    return renderLayout(<UserDashboard onNavigate={handleNavClick} />, 'max-w-4xl');
  }

  // Profile View
  if (activeView === 'profile') {
    return renderLayout(<UserProfile />, 'max-w-4xl');
  }

  // Settings View
  if (activeView === 'settings') {
    return renderLayout(<UserSettings />, 'max-w-4xl');
  }

  // Notifications View
  if (activeView === 'notifications') {
    return renderLayout(<NotificationsCenter />, 'max-w-4xl');
  }

  // Messages View
  if (activeView === 'messages') {
    return renderLayout(<MessagesCenter />, 'max-w-5xl');
  }

  // Posts View
  if (activeView === 'posts') {
    return renderLayout(
      <PostsSection onBack={() => setActiveView('landing')} />,
      'max-w-4xl'
    );
  }

  // Companies View
  if (activeView === 'companies') {
    return renderLayout(
      <CompaniesSection onBack={() => setActiveView('landing')} />,
      'max-w-6xl'
    );
  }

  // Craftsmen View
  if (activeView === 'craftsmen') {
    return renderLayout(
      <CraftsmenSection onBack={() => setActiveView('landing')} />,
      'max-w-6xl'
    );
  }

  // Market View
  if (activeView === 'market') {
    return renderLayout(
      <MarketSection onBack={() => setActiveView('landing')} />,
      'max-w-6xl'
    );
  }

  // Questions View
  if (activeView === 'questions') {
    return renderLayout(
      <QuestionsSection onBack={() => setActiveView('landing')} />,
      'max-w-4xl'
    );
  }

  // Jobs View
  if (activeView === 'jobs') {
    return renderLayout(
      <JobsSection onBack={() => setActiveView('landing')} />,
      'max-w-5xl'
    );
  }

  // Calculator View
  if (activeView === 'calculator') {
    return renderLayout(
      <CalculatorSection onBack={() => setActiveView('landing')} />,
      'max-w-4xl'
    );
  }

  // Library View
  if (activeView === 'library') {
    return renderLayout(
      <LibrarySection onBack={() => setActiveView('landing')} />,
      'max-w-6xl'
    );
  }

  // Projects View
  if (activeView === 'projects') {
    return renderLayout(
      <ProjectsSection onBack={() => setActiveView('landing')} />,
      'max-w-6xl'
    );
  }

  // Landing Page (Non-logged in)
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-muted">
      <AppHeader onAuthClick={() => setAuthOpen(true)} />
      
      {/* Header Ad Banner */}
      <div className="container mx-auto px-4 pt-4">
        <AdCarousel className="max-w-4xl mx-auto" />
      </div>
      
      <main className="flex-1 flex items-center justify-center p-4">
        <div className="text-center max-w-4xl">
          <div className="mb-8">
            <div className="inline-flex items-center justify-center w-24 h-24 rounded-2xl bg-primary text-primary-foreground mb-6">
              <Building2 className="h-12 w-12" />
            </div>
            <h1 className="text-5xl font-bold mb-4">DzBuild</h1>
            <p className="text-xl text-muted-foreground mb-2">
              {translations.appDescription[locale]}
            </p>
          </div>

          {/* Features Grid - 3x3 Layout */}
          <div className="grid grid-cols-3 gap-3 mb-8 max-w-lg mx-auto">
            {allSectionNavItems.map((item, i) => (
              <button
                key={i}
                onClick={() => handleNavClick(item.view)}
                className="flex flex-col items-center gap-2 p-3 rounded-xl bg-card border hover:shadow-lg transition-all cursor-pointer hover:border-primary hover:scale-105"
              >
                <div className={cn('p-2.5 rounded-xl text-white', item.color)}>
                  <item.icon className="h-5 w-5" />
                </div>
                <span className="font-medium text-xs text-center">
                  {item.key === 'posts' 
                    ? translations.posts[locale]
                    : translations.features[item.key as keyof typeof translations.features]?.[locale] || item.key
                  }
                </span>
              </button>
            ))}
          </div>

          {/* Hide login buttons when user is logged in */}
          {!isLoggedIn && (
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button size="lg" onClick={() => setAuthOpen(true)} className="px-8">
                {translations.startFree[locale]}
              </Button>
              <Button size="lg" variant="outline" onClick={() => setAuthOpen(true)}>
                {translations.login[locale]}
              </Button>
            </div>
          )}

          {/* Stats */}
          <div className="flex justify-center gap-8 mt-8 text-center">
            <div>
              <p className="text-2xl font-bold text-primary">{stats.artisans.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">{translations.artisans[locale]}</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary">{stats.engineers.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">{translations.engineers[locale]}</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary">{stats.companies.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">{translations.companiesCount[locale]}</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-primary">{stats.projects.toLocaleString()}</p>
              <p className="text-sm text-muted-foreground">{translations.projectsCount[locale]}</p>
            </div>
          </div>
        </div>
      </main>

      <footer className="mt-auto p-4 text-center text-muted-foreground text-sm border-t">
        © 2024 DzBuild - {translations.allRightsReserved[locale]}
      </footer>
      {/* Only show AuthDialog when user is NOT logged in */}
      {!isLoggedIn && <AuthDialog open={authOpen} onOpenChange={(v) => { if (!v) setOauthError(null); setAuthOpen(v); }} externalError={oauthError} />}
      <AdPopup />
    </div>
  );
}
