import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { hashPassword, createSession } from '@/lib/auth';

export async function OPTIONS() {
  return NextResponse.json(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, password, role = 'NORMAL_USER', phone, wilaya, city } = body;

    // Validation
    if (!email || !password || !name) {
      return NextResponse.json(
        { error: 'جميع الحقول مطلوبة / Tous les champs sont requis' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل / Le mot de passe doit contenir au moins 6 caractères' },
        { status: 400 }
      );
    }

    if (name.length < 2) {
      return NextResponse.json(
        { error: 'الاسم يجب أن يكون حرفين على الأقل / Le nom doit contenir au moins 2 caractères' },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'البريد الإلكتروني غير صالح / Email invalide' },
        { status: 400 }
      );
    }

    const normalizedEmail = email.toLowerCase().trim();

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email: normalizedEmail },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'البريد الإلكتروني مسجل مسبقاً / Email déjà enregistré' },
        { status: 400 }
      );
    }

    // Hash password
    const hashedPassword = await hashPassword(password);

    // Map role string to UserRole enum
    const roleMap: Record<string, string> = {
      'NORMAL_USER': 'NORMAL_USER',
      'CIVIL_ENGINEER': 'CIVIL_ENGINEER',
      'CONTRACTOR': 'CONTRACTOR',
      'ENGINEERING_OFFICE': 'ENGINEERING_OFFICE',
      'CRAFTSMAN': 'CRAFTSMAN',
      'CONSTRUCTION_COMPANY': 'CONSTRUCTION_COMPANY',
      'STORE_FACTORY': 'STORE_FACTORY',
      'ADMIN': 'ADMIN',
    };

    const userRole = roleMap[role] || 'NORMAL_USER';

    // Create user
    const user = await db.user.create({
      data: {
        email: normalizedEmail,
        password: hashedPassword,
        name: name.trim(),
        phone: phone?.trim() || null,
        wilaya: wilaya?.trim() || null,
        city: city?.trim() || null,
        role: userRole as any,
        isVerified: false,
        isActive: true,
        isEmailVerified: false,
        rating: 0,
        reviewCount: 0,
        projectCount: 0,
      },
    });

    // Create session
    await createSession(user.id);

    // Return user without password
    return NextResponse.json({
      success: true,
      message: 'تم إنشاء الحساب بنجاح / Compte créé avec succès',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
        phone: user.phone,
        isVerified: user.isVerified,
        rating: user.rating,
        reviewCount: user.reviewCount,
        city: user.city,
        wilaya: user.wilaya,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'فشل إنشاء الحساب / Échec de la création du compte' },
      { status: 500 }
    );
  }
}
