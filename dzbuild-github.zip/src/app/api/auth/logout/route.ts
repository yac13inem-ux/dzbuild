import { NextResponse } from 'next/server';
import { clearSession } from '@/lib/auth';

// Handle OPTIONS for CORS
export async function OPTIONS() {
  return NextResponse.json(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

export async function POST() {
  try {
    await clearSession();
    return NextResponse.json({ 
      success: true, 
      message: 'تم تسجيل الخروج بنجاح / Déconnexion réussie' 
    });
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json({ 
      success: true, 
      message: 'تم تسجيل الخروج / Déconnecté' 
    });
  }
}
