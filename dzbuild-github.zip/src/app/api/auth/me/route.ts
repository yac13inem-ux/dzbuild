import { NextRequest, NextResponse } from 'next/server';
import { getCurrentUser } from '@/lib/auth';

// Handle OPTIONS for CORS
export async function OPTIONS() {
  return NextResponse.json(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-user-id',
    },
  });
}

export async function GET(request: NextRequest) {
  try {
    // First try to get user from session cookie
    const user = await getCurrentUser();

    if (user) {
      return NextResponse.json({ user });
    }

    // Fallback: try to get user from header (for backward compatibility)
    const userId = request.headers.get('x-user-id');

    if (!userId) {
      return NextResponse.json({ user: null }, { status: 200 });
    }

    // Import db only if needed
    const { db } = await import('@/lib/db');
    
    const headerUser = await db.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        avatar: true,
        phone: true,
        isVerified: true,
        rating: true,
        reviewCount: true,
        city: true,
        wilaya: true,
        specialization: true,
        bio: true,
        isActive: true,
      },
    });

    if (!headerUser || !headerUser.isActive) {
      return NextResponse.json({ user: null }, { status: 200 });
    }

    return NextResponse.json({ user: headerUser });
  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json(
      { user: null, error: 'Failed to get user' },
      { status: 200 }
    );
  }
}
