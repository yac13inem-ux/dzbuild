import { NextRequest, NextResponse } from 'next/server';

// Question categories with Arabic and French names
export const QUESTION_CATEGORIES = [
  { 
    id: 'concrete', 
    nameAr: '📌 أسئلة خرسانة', 
    nameFr: '📌 Questions Béton', 
    shortNameAr: 'خرسانة',
    shortNameFr: 'Béton',
    icon: '🏗️', 
    color: 'bg-gray-500',
    subcategories: [
      { id: 'mix_design', nameAr: 'تصميم الخلطات', nameFr: 'Formulation' },
      { id: 'pouring', nameAr: 'مشاكل الصب', nameFr: 'Problèmes de coulage' },
      { id: 'cracks', nameAr: 'التشققات', nameFr: 'Fissures' },
    ]
  },
  { 
    id: 'reinforcement', 
    nameAr: '📌 أسئلة حديد التسليح', 
    nameFr: '📌 Questions Armature', 
    shortNameAr: 'حديد التسليح',
    shortNameFr: 'Armature',
    icon: '🔩', 
    color: 'bg-slate-600',
    subcategories: [
      { id: 'lap_length', nameAr: 'أطوال التراكب', nameFr: 'Longueurs de recouvrement' },
      { id: 'joints', nameAr: 'تفاصيل العقد', nameFr: 'Détails des nœuds' },
      { id: 'stirrups', nameAr: 'الكانات', nameFr: 'Étriers' },
    ]
  },
  { 
    id: 'foundations', 
    nameAr: '📌 أسئلة الأساسات', 
    nameFr: '📌 Questions Fondations', 
    shortNameAr: 'الأساسات',
    shortNameFr: 'Fondations',
    icon: '🧱', 
    color: 'bg-stone-600',
    subcategories: [
      { id: 'types', nameAr: 'أنواع الأساسات', nameFr: 'Types de fondations' },
      { id: 'settlement', nameAr: 'مشاكل الهبوط', nameFr: 'Problèmes de tassement' },
      { id: 'waterproofing', nameAr: 'العزل', nameFr: 'Étanchéité' },
    ]
  },
  { 
    id: 'site', 
    nameAr: '📌 أسئلة الموقع', 
    nameFr: '📌 Questions Chantier', 
    shortNameAr: 'الموقع',
    shortNameFr: 'Chantier',
    icon: '📍', 
    color: 'bg-orange-500',
    subcategories: [
      { id: 'levels', nameAr: 'ضبط المناسيب', nameFr: 'Nivellement' },
      { id: 'execution', nameAr: 'مشاكل التنفيذ', nameFr: 'Problèmes d\'exécution' },
      { id: 'errors', nameAr: 'أخطاء العمال', nameFr: 'Erreurs des ouvriers' },
    ]
  },
];

// GET - Public API for questions (no auth required)
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const subcategory = searchParams.get('subcategory');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    // If Supabase is not ready, return empty but with categories info
    if (!isSupabaseReady) {
      return NextResponse.json({ 
        questions: [],
        categories: QUESTION_CATEGORIES,
        total: 0 
      });
    }

    // Build query
    let query = supabase
      .from('questions')
      .select('*', { count: 'exact' });

    // Apply filters
    if (category && category !== 'all') {
      query = query.eq('category', category);
    }

    if (subcategory) {
      query = query.eq('subcategory', subcategory);
    }
    
    // Simple text search
    if (search) {
      query = query.or(`title.ilike.%${search}%,content.ilike.%${search}%`);
    }

    // Simple ordering and pagination
    query = query
      .order('is_pinned', { ascending: false })
      .order('votes_count', { ascending: false })
      .order('createdAt', { ascending: false })
      .range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error('Error fetching questions:', error);
      return NextResponse.json({ 
        questions: [], 
        categories: QUESTION_CATEGORIES,
        total: 0,
        error: error.message 
      });
    }

    // Normalize the data for frontend
    const normalizedQuestions = (data || []).map(q => ({
      ...q,
      answers_count: q.answersCount ?? q.answers_count ?? 0,
      votes_count: q.votesCount ?? q.votes_count ?? 0,
      views_count: q.viewsCount ?? q.views_count ?? 0,
      is_solved: q.isSolved ?? q.is_solved ?? false,
      is_pinned: q.isPinned ?? q.is_pinned ?? false,
      created_at: q.createdAt || q.created_at,
    }));

    return NextResponse.json({ 
      questions: normalizedQuestions, 
      categories: QUESTION_CATEGORIES,
      total: count || 0
    });
  } catch (error) {
    console.error('Questions API error:', error);
    return NextResponse.json({ 
      questions: [], 
      categories: QUESTION_CATEGORIES,
      total: 0 
    });
  }
}

// POST - Create new question
export async function POST(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const {
      title,
      content,
      category,
      subcategory,
      images,
      author_id,
      author_name,
      author_role,
    } = body;

    if (!title || !category) {
      return NextResponse.json({ 
        error: 'Title and category are required' 
      }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('questions')
      .insert({
        title,
        content,
        category,
        subcategory,
        images: images || [],
        author_id,
        author_name,
        author_role,
        answers_count: 0,
        votes_count: 0,
        views_count: 0,
        is_solved: false,
        is_pinned: false,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating question:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, question: data });
  } catch (error) {
    console.error('Create question error:', error);
    return NextResponse.json({ error: 'Failed to create question' }, { status: 500 });
  }
}
