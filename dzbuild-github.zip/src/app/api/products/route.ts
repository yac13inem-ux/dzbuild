import { NextRequest, NextResponse } from 'next/server';

// Product categories with Arabic and French names
export const PRODUCT_CATEGORIES = [
  { id: 'cement', nameAr: '🪨 إسمنت', nameFr: '🪨 Ciment', shortNameAr: 'إسمنت', shortNameFr: 'Ciment', icon: '🪨', color: 'bg-gray-500', unit: 'شيك' },
  { id: 'steel', nameAr: '🔩 حديد', nameFr: '🔩 Acier', shortNameAr: 'حديد', shortNameFr: 'Acier', icon: '🔩', color: 'bg-slate-600', unit: 'طن' },
  { id: 'bricks', nameAr: '🧱 طوب', nameFr: '🧱 Briques', shortNameAr: 'طوب', shortNameFr: 'Briques', icon: '🧱', color: 'bg-orange-500', unit: 'قطعة' },
  { id: 'sand', nameAr: '🏖️ رمل', nameFr: '🏖️ Sable', shortNameAr: 'رمل', shortNameFr: 'Sable', icon: '🏖️', color: 'bg-yellow-600', unit: 'م³' },
  { id: 'gravel', nameAr: '🪨 حصى', nameFr: '🪨 Gravier', shortNameAr: 'حصى', shortNameFr: 'Gravier', icon: '🪨', color: 'bg-stone-500', unit: 'م³' },
  { id: 'tools', nameAr: '🔧 أدوات بناء', nameFr: '🔧 Outils', shortNameAr: 'أدوات', shortNameFr: 'Outils', icon: '🔧', color: 'bg-red-500', unit: 'قطعة' },
  { id: 'equipment', nameAr: '🚜 معدات', nameFr: '🚜 Équipements', shortNameAr: 'معدات', shortNameFr: 'Équipements', icon: '🚜', color: 'bg-amber-600', unit: 'وحدة' },
];

// Wilayas of Algeria
export const WILAYAS = [
  'أدرار', 'الشلف', 'الأغواط', 'أم البواقي', 'باتنة', 'بجاية', 'بسكرة', 'بشار',
  'البليدة', 'البويرة', 'تمنراست', 'تبسة', 'تلمسان', 'تيارت', 'تيزي وزو', 'الجزائر',
  'عين الدفلى', 'جيجل', 'سطيف', 'سعيدة', 'سكيكدة', 'سيدي بلعباس', 'عنابة', 'قالمة',
  'قسنطينة', 'المدية', 'مستغانم', 'المسيلة', 'معسكر', 'ورقلة', 'وهران', 'البيض',
  'إليزي', 'برج بوعريريج', 'بومرداس', 'الطارف', 'تندوف', 'تيسمسيلت', 'الوادي', 'خنشلة',
  'سوق أهراس', 'ميلة', 'النعامة', 'عين تموشنت', 'غرداية', 'غليزان'
];

// GET - Public API for products (no auth required)
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const wilaya = searchParams.get('wilaya');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    // If Supabase is not ready, return empty but with categories info
    if (!isSupabaseReady) {
      return NextResponse.json({ 
        products: [],
        categories: PRODUCT_CATEGORIES,
        wilayas: WILAYAS,
        total: 0 
      });
    }

    // Build query
    let query = supabase
      .from('products')
      .select('*', { count: 'exact' });

    // Apply filters
    if (category && category !== 'all') {
      query = query.eq('category', category);
    }
    
    if (wilaya) {
      query = query.eq('wilaya', wilaya);
    }
    
    // Simple text search
    if (search) {
      query = query.or(`title.ilike.%${search}%,supplier_name.ilike.%${search}%`);
    }

    // Simple ordering and pagination
    query = query
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error('Error fetching products:', error);
      return NextResponse.json({ 
        products: [], 
        categories: PRODUCT_CATEGORIES,
        wilayas: WILAYAS,
        total: 0,
        error: error.message 
      });
    }

    return NextResponse.json({ 
      products: data || [], 
      categories: PRODUCT_CATEGORIES,
      wilayas: WILAYAS,
      total: count || 0
    });
  } catch (error) {
    console.error('Products API error:', error);
    return NextResponse.json({ 
      products: [], 
      categories: PRODUCT_CATEGORIES,
      wilayas: WILAYAS,
      total: 0 
    });
  }
}

// POST - Create new product
export async function POST(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const {
      title,
      description,
      category,
      price,
      unit,
      quantity_available,
      supplier_name,
      supplier_phone,
      supplier_email,
      wilaya,
      city,
      images,
      is_featured,
    } = body;

    if (!title || !category || !price) {
      return NextResponse.json({ 
        error: 'Title, category and price are required' 
      }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('products')
      .insert({
        title,
        description,
        category,
        price,
        unit,
        quantity_available,
        supplier_name,
        supplier_phone,
        supplier_email,
        wilaya,
        city,
        images: images || [],
        is_featured: is_featured || false,
        is_active: true,
        views_count: 0,
        inquiries_count: 0,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating product:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, product: data });
  } catch (error) {
    console.error('Create product error:', error);
    return NextResponse.json({ error: 'Failed to create product' }, { status: 500 });
  }
}
