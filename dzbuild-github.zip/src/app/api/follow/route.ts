import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';

// POST - Toggle follow
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { follower_id, following_id } = body;

    if (!follower_id || !following_id) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    if (follower_id === following_id) {
      return NextResponse.json(
        { error: 'Cannot follow yourself' },
        { status: 400 }
      );
    }

    // Check if already following
    const { data: existingFollow } = await supabase
      .from('follows')
      .select('id')
      .eq('follower_id', follower_id)
      .eq('following_id', following_id)
      .single();

    if (existingFollow) {
      // Unfollow
      const { error: deleteError } = await supabase
        .from('follows')
        .delete()
        .eq('id', existingFollow.id);

      if (deleteError) {
        console.error('Error unfollowing:', deleteError);
        return NextResponse.json({ error: 'Failed to unfollow' }, { status: 500 });
      }

      // Update counters
      const { data: follower } = await supabase
        .from('profiles')
        .select('following_count')
        .eq('id', follower_id)
        .single();

      const { data: following } = await supabase
        .from('profiles')
        .select('followers_count')
        .eq('id', following_id)
        .single();

      if (follower) {
        await supabase
          .from('profiles')
          .update({ following_count: Math.max(0, (follower.following_count || 0) - 1) })
          .eq('id', follower_id);
      }

      if (following) {
        await supabase
          .from('profiles')
          .update({ followers_count: Math.max(0, (following.followers_count || 0) - 1) })
          .eq('id', following_id);
      }

      return NextResponse.json({ following: false, message: 'Unfollowed' });
    } else {
      // Follow
      const { error: insertError } = await supabase
        .from('follows')
        .insert({
          follower_id,
          following_id,
        });

      if (insertError) {
        console.error('Error following:', insertError);
        return NextResponse.json({ error: 'Failed to follow' }, { status: 500 });
      }

      // Update counters
      const { data: follower } = await supabase
        .from('profiles')
        .select('following_count')
        .eq('id', follower_id)
        .single();

      const { data: following } = await supabase
        .from('profiles')
        .select('followers_count')
        .eq('id', following_id)
        .single();

      if (follower) {
        await supabase
          .from('profiles')
          .update({ following_count: (follower.following_count || 0) + 1 })
          .eq('id', follower_id);
      }

      if (following) {
        await supabase
          .from('profiles')
          .update({ followers_count: (following.followers_count || 0) + 1 })
          .eq('id', following_id);
      }

      return NextResponse.json({ following: true, message: 'Following' });
    }
  } catch (error) {
    console.error('Follow toggle error:', error);
    return NextResponse.json({ error: 'Failed to toggle follow' }, { status: 500 });
  }
}

// GET - Get followers/following
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const type = searchParams.get('type'); // 'followers' or 'following'
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    if (!userId || !type) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
    }

    let query;
    if (type === 'followers') {
      query = supabase
        .from('follows')
        .select(`
          created_at,
          follower:profiles!follows_follower_id_fkey (
            id,
            name,
            avatar,
            role,
            specialization
          )
        `)
        .eq('following_id', userId)
        .range(offset, offset + limit - 1);
    } else {
      query = supabase
        .from('follows')
        .select(`
          created_at,
          following:profiles!follows_following_id_fkey (
            id,
            name,
            avatar,
            role,
            specialization
          )
        `)
        .eq('follower_id', userId)
        .range(offset, offset + limit - 1);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Error fetching follows:', error);
      return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 });
    }

    const users = data?.map(f => type === 'followers' ? f.follower : f.following) || [];

    return NextResponse.json({ users });
  } catch (error) {
    console.error('Follow fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch' }, { status: 500 });
  }
}
