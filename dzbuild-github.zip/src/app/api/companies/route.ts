import { NextRequest, NextResponse } from 'next/server';

// Company types with Arabic and French names
export const COMPANY_TYPES = [
  { id: 'BET', nameAr: 'مكتب دراسات (BET)', nameFr: "Bureau d'Études Techniques", icon: '🏢', description: 'مكاتب هندسية متخصصة في التصميم والدراسات التقنية' },
  { id: 'CONSTRUCTION', nameAr: 'شركات مقاولات', nameFr: 'Entreprise de Construction', icon: '🏗️', description: 'شركات متخصصة في أشمال البناء والتشييد' },
  { id: 'MATERIALS', nameAr: 'شركات مواد البناء', nameFr: 'Fournisseur de Matériaux', icon: '🧱', description: 'موردين ومصنعي مواد البناء' },
  { id: 'SURVEY', nameAr: 'مكاتب مسح طوبوغرافي', nameFr: 'Cabinet de Topographie', icon: '📐', description: 'مكاتب متخصصة في المسح والخرائط' },
  { id: 'ELECTRICAL_MECHANICAL', nameAr: 'شركات كهرباء وميكانيك', nameFr: 'Entreprise Électromécanique', icon: '⚡', description: 'شركات متخصصة في التركيبات الكهربائية والميكانيكية' },
];

// Wilayas of Algeria
export const WILAYAS = [
  'أدرار', 'الشلف', 'الأغواط', 'أم البواقي', 'باتنة', 'بجاية', 'بسكرة', 'بشار',
  'البليدة', 'البويرة', 'تمنراست', 'تبسة', 'تلمسان', 'تيارت', 'تيزي وزو', 'الجزائر',
  'عين الدفلى', 'جيجل', 'سطيف', 'سعيدة', 'سكيكدة', 'سيدي بلعباس', 'عنابة', 'قالمة',
  'قسنطينة', 'المدية', 'مستغانم', 'المسيلة', 'معسكر', 'ورقلة', 'وهران', 'البيض',
  'إليزي', 'برج بوعريريج', 'بومرداس', 'الطارف', 'تندوف', 'تيسمسيلت', 'الوادي', 'خنشلة',
  'سوق أهراس', 'ميلة', 'النعامة', 'عين تموشنت', 'غرداية', 'غليزان'
];

// GET - Public API for companies (no auth required)
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const wilaya = searchParams.get('wilaya');
    const city = searchParams.get('city');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    // If Supabase is not ready, return empty but with types info
    if (!isSupabaseReady) {
      return NextResponse.json({ 
        companies: [],
        types: COMPANY_TYPES,
        wilayas: WILAYAS,
        total: 0 
      });
    }

    // Build query - use basic select without complex filters
    let query = supabase
      .from('companies')
      .select('*', { count: 'exact' });

    // Apply simple filters
    if (type && type !== 'all') {
      query = query.eq('companyType', type);
    }
    
    if (wilaya) {
      query = query.eq('wilaya', wilaya);
    }
    
    if (city) {
      query = query.ilike('city', `%${city}%`);
    }
    
    // Simple text search
    if (search) {
      query = query.or(`name.ilike.%${search}%,nameFr.ilike.%${search}%`);
    }

    // Simple ordering and pagination
    query = query
      .order('createdAt', { ascending: false })
      .range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error('Error fetching companies:', error);
      // Return empty result with types info instead of error
      return NextResponse.json({ 
        companies: [], 
        types: COMPANY_TYPES,
        wilayas: WILAYAS,
        total: 0,
        error: error.message 
      });
    }

    // Normalize the data for frontend
    const normalizedCompanies = (data || []).map(company => ({
      ...company,
      // Map camelCase to snake_case for frontend compatibility
      company_type: company.companyType || company.company_type,
      name_fr: company.nameFr || company.name_fr,
      description_fr: company.descriptionFr || company.description_fr,
      logo_url: company.logoUrl || company.logo_url,
      cover_image_url: company.coverImageUrl || company.cover_image_url,
      postal_code: company.postalCode || company.postal_code,
      founded_year: company.foundedYear || company.founded_year,
      employee_count_range: company.employeeCountRange || company.employee_count_range,
      is_verified: company.isVerified ?? company.is_verified ?? false,
      is_featured: company.isFeatured ?? company.is_featured ?? false,
      is_active: company.isActive ?? company.is_active ?? true,
      review_count: company.reviewCount ?? company.review_count ?? 0,
      project_count: company.projectCount ?? company.project_count ?? 0,
      views_count: company.viewsCount ?? company.views_count ?? 0,
      created_at: company.createdAt || company.created_at,
      updated_at: company.updatedAt || company.updated_at,
    }));

    return NextResponse.json({ 
      companies: normalizedCompanies, 
      types: COMPANY_TYPES,
      wilayas: WILAYAS,
      total: count || 0
    });
  } catch (error) {
    console.error('Companies API error:', error);
    return NextResponse.json({ 
      companies: [], 
      types: COMPANY_TYPES,
      wilayas: WILAYAS,
      total: 0 
    });
  }
}
