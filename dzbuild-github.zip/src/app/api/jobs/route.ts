import { NextRequest, NextResponse } from 'next/server';

// Job categories with Arabic and French names
export const JOB_CATEGORIES = [
  { 
    id: 'engineers', 
    nameAr: '👷 وظائف مهندسين', 
    nameFr: '👷 Emplois Ingénieurs', 
    shortNameAr: 'مهندسين',
    shortNameFr: 'Ingénieurs',
    icon: '👷', 
    color: 'bg-blue-500' 
  },
  { 
    id: 'technicians', 
    nameAr: '👷‍♂️ وظائف تقنيين', 
    nameFr: '👷‍♂️ Emplois Techniciens', 
    shortNameAr: 'تقنيين',
    shortNameFr: 'Techniciens',
    icon: '👷‍♂️', 
    color: 'bg-teal-500' 
  },
  { 
    id: 'workers', 
    nameAr: '🧱 وظائف عمال', 
    nameFr: '🧱 Emplois Ouvriers', 
    shortNameAr: 'عمال',
    shortNameFr: 'Ouvriers',
    icon: '🧱', 
    color: 'bg-orange-500' 
  },
  { 
    id: 'internships', 
    nameAr: '🏗 تدريب للطلبة', 
    nameFr: '🏗 Stages Étudiants', 
    shortNameAr: 'تدريب',
    shortNameFr: 'Stages',
    icon: '🏗', 
    color: 'bg-purple-500' 
  },
];

// Wilayas of Algeria
export const WILAYAS = [
  'أدرار', 'الشلف', 'الأغواط', 'أم البواقي', 'باتنة', 'بجاية', 'بسكرة', 'بشار',
  'البليدة', 'البويرة', 'تمنراست', 'تبسة', 'تلمسان', 'تيارت', 'تيزي وزو', 'الجزائر',
  'عين الدفلى', 'جيجل', 'سطيف', 'سعيدة', 'سكيكدة', 'سيدي بلعباس', 'عنابة', 'قالمة',
  'قسنطينة', 'المدية', 'مستغانم', 'المسيلة', 'معسكر', 'ورقلة', 'وهران', 'البيض',
  'إليزي', 'برج بوعريريج', 'بومرداس', 'الطارف', 'تندوف', 'تيسمسيلت', 'الوادي', 'خنشلة',
  'سوق أهراس', 'ميلة', 'النعامة', 'عين تموشنت', 'غرداية', 'غليزان'
];

// Experience levels
export const EXPERIENCE_LEVELS = [
  { id: 'entry', nameAr: 'مبتدئ (0-1 سنة)', nameFr: 'Débutant (0-1 an)' },
  { id: 'junior', nameAr: 'مبتدئ (1-3 سنوات)', nameFr: 'Junior (1-3 ans)' },
  { id: 'mid', nameAr: 'متوسط (3-5 سنوات)', nameFr: 'Intermédiaire (3-5 ans)' },
  { id: 'senior', nameAr: 'خبير (5+ سنوات)', nameFr: 'Senior (5+ ans)' },
  { id: 'any', nameAr: 'غير محدد', nameFr: 'Non spécifié' },
];

// GET - Public API for jobs (no auth required)
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const wilaya = searchParams.get('wilaya');
    const experience = searchParams.get('experience');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    // If Supabase is not ready, return empty but with categories info
    if (!isSupabaseReady) {
      return NextResponse.json({ 
        jobs: [],
        categories: JOB_CATEGORIES,
        wilayas: WILAYAS,
        experienceLevels: EXPERIENCE_LEVELS,
        total: 0 
      });
    }

    // Build query
    let query = supabase
      .from('jobs')
      .select('*', { count: 'exact' });

    // Apply filters
    if (category && category !== 'all') {
      query = query.eq('category', category);
    }
    
    if (wilaya) {
      query = query.eq('wilaya', wilaya);
    }
    
    if (experience) {
      query = query.eq('experience_level', experience);
    }
    
    // Simple text search
    if (search) {
      query = query.or(`title.ilike.%${search}%,company_name.ilike.%${search}%`);
    }

    // Simple ordering and pagination
    query = query
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error('Error fetching jobs:', error);
      return NextResponse.json({ 
        jobs: [], 
        categories: JOB_CATEGORIES,
        wilayas: WILAYAS,
        experienceLevels: EXPERIENCE_LEVELS,
        total: 0,
        error: error.message 
      });
    }

    return NextResponse.json({ 
      jobs: data || [], 
      categories: JOB_CATEGORIES,
      wilayas: WILAYAS,
      experienceLevels: EXPERIENCE_LEVELS,
      total: count || 0
    });
  } catch (error) {
    console.error('Jobs API error:', error);
    return NextResponse.json({ 
      jobs: [], 
      categories: JOB_CATEGORIES,
      wilayas: WILAYAS,
      experienceLevels: EXPERIENCE_LEVELS,
      total: 0 
    });
  }
}

// POST - Create new job
export async function POST(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const {
      title,
      description,
      category,
      company_name,
      company_logo,
      wilaya,
      city,
      experience_level,
      experience_required,
      salary_range,
      job_type,
      application_method,
      contact_email,
      contact_phone,
      deadline,
      requirements,
      benefits,
      is_featured,
    } = body;

    if (!title || !category || !company_name) {
      return NextResponse.json({ 
        error: 'Title, category and company name are required' 
      }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('jobs')
      .insert({
        title,
        description,
        category,
        company_name,
        company_logo,
        wilaya,
        city,
        experience_level,
        experience_required,
        salary_range,
        job_type,
        application_method,
        contact_email,
        contact_phone,
        deadline,
        requirements: requirements || [],
        benefits: benefits || [],
        is_featured: is_featured || false,
        is_active: true,
        views_count: 0,
        applications_count: 0,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating job:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, job: data });
  } catch (error) {
    console.error('Create job error:', error);
    return NextResponse.json({ error: 'Failed to create job' }, { status: 500 });
  }
}
