import { NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

// GET - Fetch all projects
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const status = searchParams.get('status');
    
    const where: Record<string, unknown> = { isPublished: true };
    
    if (category && category !== 'all') {
      where.category = category;
    }
    
    if (status && status !== 'all') {
      where.status = status;
    }
    
    const projects = await prisma.project.findMany({
      where,
      orderBy: [
        { isFeatured: 'desc' },
        { createdAt: 'desc' },
      ],
    });
    
    return NextResponse.json({ projects });
  } catch (error) {
    console.error('Error fetching projects:', error);
    return NextResponse.json({ projects: [], error: 'Failed to fetch projects' }, { status: 500 });
  }
}

// POST - Create a new project
export async function POST(request: Request) {
  try {
    const data = await request.json();
    
    const project = await prisma.project.create({
      data: {
        title: data.title,
        titleAr: data.titleAr,
        titleFr: data.titleFr,
        description: data.description,
        descriptionAr: data.descriptionAr,
        descriptionFr: data.descriptionFr,
        status: data.status || 'planning',
        category: data.category || 'other',
        progress: data.progress || 0,
        location: data.location,
        city: data.city,
        wilaya: data.wilaya,
        budget: data.budget ? parseFloat(data.budget) : null,
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        clientName: data.clientName,
        clientPhone: data.clientPhone,
        clientEmail: data.clientEmail,
        isFeatured: data.isFeatured || false,
        isPublished: true,
        createdById: data.createdById,
      },
    });
    
    return NextResponse.json({ project });
  } catch (error) {
    console.error('Error creating project:', error);
    return NextResponse.json({ error: 'Failed to create project' }, { status: 500 });
  }
}
