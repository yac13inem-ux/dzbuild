import { NextRequest, NextResponse } from 'next/server';

// Craftsman categories with Arabic and French names
export const CRAFTSMAN_CATEGORIES = [
  { id: 'electrician', nameAr: 'كهربائي', nameFr: 'Électricien', icon: '⚡', color: 'bg-yellow-500' },
  { id: 'plumber', nameAr: 'سباك', nameFr: 'Plombier', icon: '🔧', color: 'bg-blue-500' },
  { id: 'carpenter', nameAr: 'نجار', nameFr: 'Menuisier', icon: '🪚', color: 'bg-amber-600' },
  { id: 'blacksmith', nameAr: 'حداد', nameFr: 'Forgeron', icon: '🔨', color: 'bg-gray-600' },
  { id: 'tiler', nameAr: 'بلاط', nameFr: 'Carreleur', icon: '🧱', color: 'bg-orange-500' },
  { id: 'painter', nameAr: 'دهان', nameFr: 'Peintre', icon: '🎨', color: 'bg-purple-500' },
  { id: 'insulator', nameAr: 'عازل أسطح', nameFr: 'Isolateur', icon: '🏠', color: 'bg-teal-500' },
  { id: 'aluminum', nameAr: 'نجار ألمنيوم', nameFr: 'Aluminier', icon: '🪟', color: 'bg-cyan-500' },
];

// Wilayas of Algeria
export const WILAYAS = [
  'أدرار', 'الشلف', 'الأغواط', 'أم البواقي', 'باتنة', 'بجاية', 'بسكرة', 'بشار',
  'البليدة', 'البويرة', 'تمنراست', 'تبسة', 'تلمسان', 'تيارت', 'تيزي وزو', 'الجزائر',
  'عين الدفلى', 'جيجل', 'سطيف', 'سعيدة', 'سكيكدة', 'سيدي بلعباس', 'عنابة', 'قالمة',
  'قسنطينة', 'المدية', 'مستغانم', 'المسيلة', 'معسكر', 'ورقلة', 'وهران', 'البيض',
  'إليزي', 'برج بوعريريج', 'بومرداس', 'الطارف', 'تندوف', 'تيسمسيلت', 'الوادي', 'خنشلة',
  'سوق أهراس', 'ميلة', 'النعامة', 'عين تموشنت', 'غرداية', 'غليزان'
];

// GET - Public API for craftsmen (no auth required)
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const wilaya = searchParams.get('wilaya');
    const city = searchParams.get('city');
    const search = searchParams.get('search');
    const limit = parseInt(searchParams.get('limit') || '50');
    const offset = parseInt(searchParams.get('offset') || '0');

    // If Supabase is not ready, return empty but with categories info
    if (!isSupabaseReady) {
      return NextResponse.json({ 
        craftsmen: [],
        categories: CRAFTSMAN_CATEGORIES,
        wilayas: WILAYAS,
        total: 0 
      });
    }

    // Build query
    let query = supabase
      .from('craftsmen')
      .select('*', { count: 'exact' });

    // Apply filters
    if (category && category !== 'all') {
      query = query.eq('category', category);
    }
    
    if (wilaya) {
      query = query.eq('wilaya', wilaya);
    }
    
    if (city) {
      query = query.ilike('city', `%${city}%`);
    }
    
    // Simple text search
    if (search) {
      query = query.or(`name.ilike.%${search}%,specialty.ilike.%${search}%`);
    }

    // Simple ordering and pagination
    query = query
      .order('rating', { ascending: false })
      .order('createdAt', { ascending: false })
      .range(offset, offset + limit - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error('Error fetching craftsmen:', error);
      return NextResponse.json({ 
        craftsmen: [], 
        categories: CRAFTSMAN_CATEGORIES,
        wilayas: WILAYAS,
        total: 0,
        error: error.message 
      });
    }

    // Normalize the data for frontend
    const normalizedCraftsmen = (data || []).map(craftsman => ({
      ...craftsman,
      is_verified: craftsman.isVerified ?? craftsman.is_verified ?? false,
      is_available: craftsman.isAvailable ?? craftsman.is_available ?? true,
      experience_years: craftsman.experienceYears ?? craftsman.experience_years ?? 0,
      review_count: craftsman.reviewCount ?? craftsman.review_count ?? 0,
      views_count: craftsman.viewsCount ?? craftsman.views_count ?? 0,
      created_at: craftsman.createdAt || craftsman.created_at,
    }));

    return NextResponse.json({ 
      craftsmen: normalizedCraftsmen, 
      categories: CRAFTSMAN_CATEGORIES,
      wilayas: WILAYAS,
      total: count || 0
    });
  } catch (error) {
    console.error('Craftsmen API error:', error);
    return NextResponse.json({ 
      craftsmen: [], 
      categories: CRAFTSMAN_CATEGORIES,
      wilayas: WILAYAS,
      total: 0 
    });
  }
}
