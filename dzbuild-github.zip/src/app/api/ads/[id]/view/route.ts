import { NextRequest, NextResponse } from 'next/server';

// Track ad view
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ success: true });
    }

    // Try direct update
    const { data: ad } = await supabase
      .from('ads')
      .select('views_count')
      .eq('id', id)
      .single();

    if (ad) {
      await supabase
        .from('ads')
        .update({ views_count: (ad.views_count || 0) + 1 })
        .eq('id', id);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ success: true });
  }
}
