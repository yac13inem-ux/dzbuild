import { NextRequest, NextResponse } from 'next/server';

// Track ad click
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ success: true });
    }

    // Try direct update
    const { data: ad } = await supabase
      .from('ads')
      .select('clicks_count')
      .eq('id', id)
      .single();

    if (ad) {
      await supabase
        .from('ads')
        .update({ clicks_count: (ad.clicks_count || 0) + 1 })
        .eq('id', id);
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ success: true });
  }
}
