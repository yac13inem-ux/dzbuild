import { NextRequest, NextResponse } from 'next/server';

// GET - Fetch active ads for public display
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ ads: [] });
    }

    const { searchParams } = new URL(request.url);
    const position = searchParams.get('position');
    const wilaya = searchParams.get('wilaya');
    const audience = searchParams.get('audience');

    const now = new Date().toISOString();

    let query = supabase
      .from('ads')
      .select('*')
      .eq('is_active', true)
      .lte('start_date', now)
      .gte('end_date', now)
      .order('priority', { ascending: false })
      .order('created_at', { ascending: false });

    if (position) {
      query = query.eq('position', position);
    }

    if (wilaya) {
      query = query.or(`wilaya.is.null,wilaya.eq.${wilaya}`);
    }

    if (audience) {
      query = query.or(`target_audience.eq.all,target_audience.eq.${audience}`);
    }

    const { data, error } = await query.limit(10);

    if (error) {
      console.error('Error fetching public ads:', error);
      return NextResponse.json({ ads: [] });
    }

    return NextResponse.json({ ads: data || [] });
  } catch (error) {
    console.error('Public ads API error:', error);
    return NextResponse.json({ ads: [] });
  }
}
