import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';

// GET - Fetch profile
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('id');
    const currentUserId = searchParams.get('currentUserId');

    if (!userId) {
      return NextResponse.json({ error: 'Missing user ID' }, { status: 400 });
    }

    const { data: profile, error } = await supabase
      .from('profiles')
      .select(`
        id,
        name,
        email,
        avatar,
        role,
        bio,
        city,
        wilaya,
        specialization,
        experience,
        license_number,
        rating,
        review_count,
        project_count,
        followers_count,
        following_count,
        is_verified,
        created_at
      `)
      .eq('id', userId)
      .single();

    if (error) {
      console.error('Error fetching profile:', error);
      return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 });
    }

    // Check if current user follows this profile
    let isFollowing = false;
    if (currentUserId && currentUserId !== userId) {
      const { data: follow } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', currentUserId)
        .eq('following_id', userId)
        .single();
      isFollowing = !!follow;
    }

    return NextResponse.json({ profile: { ...profile, is_following: isFollowing } });
  } catch (error) {
    console.error('Profile fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch profile' }, { status: 500 });
  }
}

// PUT - Update profile
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'Missing user ID' }, { status: 400 });
    }

    // Remove fields that shouldn't be updated directly
    delete updates.email;
    delete updates.role;
    delete updates.rating;
    delete updates.review_count;
    delete updates.followers_count;
    delete updates.following_count;
    delete updates.created_at;

    const { data: profile, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Error updating profile:', error);
      return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 });
    }

    return NextResponse.json({ profile });
  } catch (error) {
    console.error('Profile update error:', error);
    return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 });
  }
}
