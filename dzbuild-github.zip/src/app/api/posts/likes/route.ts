import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';

// POST - Toggle like
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { user_id, target_type, target_id } = body;

    if (!user_id || !target_type || !target_id) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Check if already liked
    const { data: existingLike } = await supabase
      .from('likes')
      .select('id')
      .eq('user_id', user_id)
      .eq('target_type', target_type)
      .eq('target_id', target_id)
      .single();

    if (existingLike) {
      // Unlike - remove the like
      const { error: deleteError } = await supabase
        .from('likes')
        .delete()
        .eq('id', existingLike.id);

      if (deleteError) {
        console.error('Error removing like:', deleteError);
        return NextResponse.json({ error: 'Failed to remove like' }, { status: 500 });
      }

      // Get current count and decrement
      const { data: post } = await supabase
        .from('posts')
        .select('likes_count')
        .eq('id', target_id)
        .single();

      if (post && target_type === 'post') {
        await supabase
          .from('posts')
          .update({ likes_count: Math.max(0, (post.likes_count || 0) - 1) })
          .eq('id', target_id);
      }

      return NextResponse.json({ liked: false, message: 'Like removed' });
    } else {
      // Like - add the like
      const { error: insertError } = await supabase
        .from('likes')
        .insert({
          user_id,
          target_type,
          target_id,
        });

      if (insertError) {
        console.error('Error adding like:', insertError);
        return NextResponse.json({ error: 'Failed to add like' }, { status: 500 });
      }

      // Get current count and increment
      const { data: post } = await supabase
        .from('posts')
        .select('likes_count')
        .eq('id', target_id)
        .single();

      if (post && target_type === 'post') {
        await supabase
          .from('posts')
          .update({ likes_count: (post.likes_count || 0) + 1 })
          .eq('id', target_id);
      }

      return NextResponse.json({ liked: true, message: 'Like added' });
    }
  } catch (error) {
    console.error('Like toggle error:', error);
    return NextResponse.json({ error: 'Failed to toggle like' }, { status: 500 });
  }
}

// GET - Check if user liked
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const targetType = searchParams.get('targetType');
    const targetId = searchParams.get('targetId');

    if (!userId || !targetType || !targetId) {
      return NextResponse.json({ liked: false });
    }

    const { data } = await supabase
      .from('likes')
      .select('id')
      .eq('user_id', userId)
      .eq('target_type', targetType)
      .eq('target_id', targetId)
      .single();

    return NextResponse.json({ liked: !!data });
  } catch (error) {
    return NextResponse.json({ liked: false });
  }
}
