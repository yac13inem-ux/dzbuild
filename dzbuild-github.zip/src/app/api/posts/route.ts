import { NextRequest, NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase/client';

// GET - Fetch posts feed
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '20');
    const offset = parseInt(searchParams.get('offset') || '0');
    const userId = searchParams.get('userId');
    const authorId = searchParams.get('authorId');
    const postType = searchParams.get('type');

    let query = supabase
      .from('posts')
      .select(`
        id,
        content,
        title,
        post_type,
        images,
        videos,
        category,
        tags,
        likes_count,
        comments_count,
        shares_count,
        views_count,
        is_featured,
        is_sponsored,
        created_at,
        author:profiles!posts_author_id_fkey (
          id,
          name,
          avatar,
          role,
          specialization,
          city,
          wilaya
        )
      `)
      .eq('is_published', true)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    // Filter by author if provided
    if (authorId) {
      query = query.eq('author_id', authorId);
    }

    // Filter by post type if provided
    if (postType) {
      query = query.eq('post_type', postType);
    }

    const { data: posts, error } = await query;

    if (error) {
      console.error('Error fetching posts:', error);
      return NextResponse.json({ error: 'Failed to fetch posts' }, { status: 500 });
    }

    // Check if user liked each post
    let postsWithLikes = posts || [];
    if (userId) {
      const postIds = posts?.map(p => p.id) || [];
      const { data: likes } = await supabase
        .from('likes')
        .select('target_id')
        .eq('user_id', userId)
        .eq('target_type', 'post')
        .in('target_id', postIds);

      const likedPostIds = new Set(likes?.map(l => l.target_id) || []);
      postsWithLikes = posts?.map(post => ({
        ...post,
        is_liked: likedPostIds.has(post.id)
      })) || [];
    }

    return NextResponse.json({ posts: postsWithLikes });
  } catch (error) {
    console.error('Posts fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch posts' }, { status: 500 });
  }
}

// POST - Create new post
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      author_id,
      content,
      title,
      post_type = 'standard',
      images = [],
      videos = [],
      category,
      tags = [],
      project_data,
      job_data,
      service_data,
      product_data,
    } = body;

    if (!author_id || (!content && !title)) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const { data: post, error } = await supabase
      .from('posts')
      .insert({
        author_id,
        content,
        title,
        post_type,
        images,
        videos,
        category,
        tags,
        project_data,
        job_data,
        service_data,
        product_data,
      })
      .select(`
        id,
        content,
        title,
        post_type,
        images,
        videos,
        category,
        tags,
        likes_count,
        comments_count,
        created_at,
        author:profiles!posts_author_id_fkey (
          id,
          name,
          avatar,
          role,
          specialization,
          city,
          wilaya
        )
      `)
      .single();

    if (error) {
      console.error('Error creating post:', error);
      return NextResponse.json({ error: 'Failed to create post' }, { status: 500 });
    }

    return NextResponse.json({ post });
  } catch (error) {
    console.error('Post creation error:', error);
    return NextResponse.json({ error: 'Failed to create post' }, { status: 500 });
  }
}

// DELETE - Delete post
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const postId = searchParams.get('id');
    const userId = searchParams.get('userId');

    if (!postId || !userId) {
      return NextResponse.json(
        { error: 'Missing post ID or user ID' },
        { status: 400 }
      );
    }

    // Verify ownership
    const { data: post } = await supabase
      .from('posts')
      .select('author_id')
      .eq('id', postId)
      .single();

    if (!post || post.author_id !== userId) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      );
    }

    const { error } = await supabase
      .from('posts')
      .delete()
      .eq('id', postId);

    if (error) {
      console.error('Error deleting post:', error);
      return NextResponse.json({ error: 'Failed to delete post' }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Post deletion error:', error);
    return NextResponse.json({ error: 'Failed to delete post' }, { status: 500 });
  }
}
