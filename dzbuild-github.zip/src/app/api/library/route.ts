import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch all library resources
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    
    const where: any = { isPublished: true };
    
    if (category && category !== 'all') {
      where.category = category;
    }
    
    const resources = await db.video.findMany({
      where,
      orderBy: [
        { isFeatured: 'desc' },
        { createdAt: 'desc' },
      ],
    });
    
    return NextResponse.json({ resources });
  } catch (error) {
    console.error('Error fetching library resources:', error);
    return NextResponse.json({ resources: [] }, { status: 500 });
  }
}
