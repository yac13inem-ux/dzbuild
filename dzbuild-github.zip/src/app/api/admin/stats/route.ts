import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Handle OPTIONS for CORS
export async function OPTIONS() {
  return NextResponse.json(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

export async function GET() {
  try {
    // Try to use Prisma database
    let userCounts = {
      total: 0,
      CIVIL_ENGINEER: 0,
      CONTRACTOR: 0,
      ENGINEERING_OFFICE: 0,
      CRAFTSMAN: 0,
      CONSTRUCTION_COMPANY: 0,
      STORE_FACTORY: 0,
      NORMAL_USER: 0,
      ADMIN: 0,
    };
    let pendingApprovals = 0;
    let adsCount = 0;
    let activeAdsCount = 0;
    let postsCount = 0;
    let craftsmenCount = 0;
    let engineersCount = 0;
    let companiesCount = 0;
    let projectsCount = 0;

    try {
      // Get user counts by role
      const users = await db.user.findMany({
        select: { role: true },
      });

      userCounts.total = users.length;
      users.forEach((user) => {
        const role = user.role as keyof typeof userCounts;
        if (role in userCounts) {
          userCounts[role]++;
        }
      });

      // Count specific roles
      engineersCount = userCounts.CIVIL_ENGINEER;
      craftsmenCount = userCounts.CRAFTSMAN;
      companiesCount = userCounts.CONSTRUCTION_COMPANY + userCounts.ENGINEERING_OFFICE + userCounts.STORE_FACTORY;

      // Get pending approvals count
      pendingApprovals = await db.user.count({
        where: { verificationStatus: 'PENDING' },
      });

      // Get ads count
      adsCount = await db.advertisement.count();
      activeAdsCount = await db.advertisement.count({
        where: { status: 'active' },
      });

      // Get posts count
      postsCount = await db.post.count();

      // Get projects count (from Company table as proxy)
      projectsCount = await db.company.count();
    } catch (dbError) {
      console.log('Database not available, using mock stats');
    }

    return NextResponse.json({
      users: userCounts,
      pendingApprovals,
      ads: {
        total: adsCount,
        active: activeAdsCount,
      },
      stats: {
        totalUsers: userCounts.total,
        totalPosts: postsCount,
        craftsmenCount,
        engineersCount,
        companiesCount,
        projectsCount,
      },
    });
  } catch (error) {
    console.error('Stats error:', error);
    return NextResponse.json(
      { error: 'Failed to get stats', users: {}, pendingApprovals: 0, ads: { total: 0, active: 0 }, stats: {} },
      { status: 200 } // Return 200 with empty data instead of 500
    );
  }
}
