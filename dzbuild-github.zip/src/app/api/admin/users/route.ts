import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Handle OPTIONS for CORS
export async function OPTIONS() {
  return NextResponse.json(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    },
  });
}

export async function GET(request: NextRequest) {
  try {
    let users: any[] = [];
    
    try {
      users = await db.user.findMany({
        select: {
          id: true,
          name: true,
          email: true,
          role: true,
          city: true,
          wilaya: true,
          isActive: true,
          isVerified: true,
          createdAt: true,
        },
        orderBy: { createdAt: 'desc' },
        take: 100,
      });

      // Transform to match expected format
      users = users.map(u => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        city: u.city,
        wilaya: u.wilaya,
        is_active: u.isActive,
        is_verified: u.isVerified,
        created_at: u.createdAt.toISOString(),
      }));
    } catch (dbError) {
      console.log('Database not available, returning empty users');
    }

    return NextResponse.json({ users });
  } catch (error) {
    console.error('Admin users API error:', error);
    return NextResponse.json({ users: [] });
  }
}
