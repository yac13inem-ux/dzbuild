import { NextRequest, NextResponse } from 'next/server';

// GET - Fetch all ads
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ ads: [] });
    }

    const { searchParams } = new URL(request.url);
    const position = searchParams.get('position');
    const activeOnly = searchParams.get('active');

    let query = supabase
      .from('ads')
      .select('*')
      .order('priority', { ascending: false })
      .order('created_at', { ascending: false });

    if (position) {
      query = query.eq('position', position);
    }

    if (activeOnly === 'true') {
      query = query.eq('is_active', true);
    }

    const { data, error } = await query.limit(100);

    if (error) {
      console.error('Error fetching ads:', error);
      return NextResponse.json({ ads: [] });
    }

    return NextResponse.json({ ads: data || [] });
  } catch (error) {
    console.error('Admin ads API error:', error);
    return NextResponse.json({ ads: [] });
  }
}

// POST - Create new ad
export async function POST(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const {
      title,
      description,
      image_url,
      link_url,
      position,
      ad_type,
      duration_days,
      start_date,
      target_audience,
      wilaya,
      priority,
    } = body;

    // Calculate end date
    const startDate = start_date ? new Date(start_date) : new Date();
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + (duration_days || 30));

    const { data, error } = await supabase
      .from('ads')
      .insert({
        title,
        description,
        image_url,
        link_url,
        position: position || 'sidebar',
        ad_type: ad_type || 'image',
        duration_days: duration_days || 30,
        start_date: startDate.toISOString(),
        end_date: endDate.toISOString(),
        target_audience: target_audience || 'all',
        wilaya,
        priority: priority || 0,
        is_active: true,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating ad:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, ad: data });
  } catch (error) {
    console.error('Create ad error:', error);
    return NextResponse.json({ error: 'Failed to create ad' }, { status: 500 });
  }
}

// PUT - Update ad
export async function PUT(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'Ad ID required' }, { status: 400 });
    }

    // Recalculate end date if duration changed
    if (updates.duration_days && updates.start_date) {
      const startDate = new Date(updates.start_date);
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + updates.duration_days);
      updates.end_date = endDate.toISOString();
    }

    updates.updated_at = new Date().toISOString();

    const { data, error } = await supabase
      .from('ads')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Error updating ad:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, ad: data });
  } catch (error) {
    console.error('Update ad error:', error);
    return NextResponse.json({ error: 'Failed to update ad' }, { status: 500 });
  }
}

// DELETE - Delete ad
export async function DELETE(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Ad ID required' }, { status: 400 });
    }

    const { error } = await supabase
      .from('ads')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting ad:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete ad error:', error);
    return NextResponse.json({ error: 'Failed to delete ad' }, { status: 500 });
  }
}
