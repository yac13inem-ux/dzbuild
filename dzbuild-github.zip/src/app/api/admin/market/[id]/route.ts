import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch single product
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const product = await db.product.findUnique({
      where: { id },
      include: {
        category: true,
        factory: true,
        company: true,
      },
    });
    
    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 });
    }
    
    return NextResponse.json({ product });
  } catch (error) {
    console.error('Error fetching product:', error);
    return NextResponse.json({ error: 'Failed to fetch product' }, { status: 500 });
  }
}

// PUT - Update product
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    console.log('Updating product:', id, 'with data:', data);
    
    const product = await db.product.update({
      where: { id },
      data: {
        name: data.name,
        nameAr: data.nameAr || null,
        nameFr: data.nameFr || null,
        description: data.description || null,
        descriptionAr: data.descriptionAr || null,
        descriptionFr: data.descriptionFr || null,
        categoryId: data.categoryId || null,
        price: data.price,
        oldPrice: data.oldPrice || null,
        unit: data.unit || 'piece',
        stock: data.stock || 0,
        isFeatured: data.isFeatured || false,
        isActive: data.isActive !== false,
      },
    });
    
    console.log('Updated product:', product);
    
    return NextResponse.json({ product });
  } catch (error) {
    console.error('Error updating product:', error);
    return NextResponse.json({ 
      error: 'Failed to update product: ' + (error as Error).message 
    }, { status: 500 });
  }
}

// DELETE - Delete product
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    console.log('DELETE request for product:', id);
    
    await db.product.delete({
      where: { id },
    });
    
    console.log('Deleted product:', id);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting product:', error);
    return NextResponse.json({ 
      error: 'Failed to delete product: ' + (error as Error).message 
    }, { status: 500 });
  }
}
