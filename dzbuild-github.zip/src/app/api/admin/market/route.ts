import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch all products for admin
export async function GET() {
  try {
    const products = await db.product.findMany({
      include: {
        category: true,
        factory: true,
        company: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    
    return NextResponse.json({ products });
  } catch (error) {
    console.error('Error fetching products:', error);
    return NextResponse.json({ products: [] }, { status: 500 });
  }
}

// POST - Create new product
export async function POST(request: Request) {
  try {
    const data = await request.json();
    console.log('Creating product with data:', data);
    
    const product = await db.product.create({
      data: {
        name: data.name || '',
        nameAr: data.nameAr || null,
        nameFr: data.nameFr || null,
        description: data.description || null,
        descriptionAr: data.descriptionAr || null,
        descriptionFr: data.descriptionFr || null,
        categoryId: data.categoryId || null,
        price: data.price || 0,
        oldPrice: data.oldPrice || null,
        unit: data.unit || 'piece',
        stock: data.stock || 0,
        isFeatured: data.isFeatured || false,
        isActive: data.isActive !== false,
      },
    });
    
    console.log('Created product:', product);
    
    return NextResponse.json({ product });
  } catch (error) {
    console.error('Error creating product:', error);
    return NextResponse.json({ 
      error: 'Failed to create product: ' + (error as Error).message 
    }, { status: 500 });
  }
}
