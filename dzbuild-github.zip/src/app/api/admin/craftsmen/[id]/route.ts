import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// DELETE - Delete a craftsman profile
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    console.log('DELETE request for craftsman:', id);
    
    // Delete the craftsman profile
    await db.craftsmanProfile.delete({
      where: { id },
    });
    
    console.log('Deleted craftsman profile:', id);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting craftsman:', error);
    return NextResponse.json({ 
      error: 'Failed to delete craftsman: ' + (error as Error).message 
    }, { status: 500 });
  }
}

// PATCH - Update a craftsman profile
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const {
      name,
      email,
      phone,
      category,
      city,
      wilaya,
      experience,
      specializations,
      hourlyRate,
      dailyRate,
      isAvailable,
      verified,
    } = body;

    // Get current craftsman profile
    const currentProfile = await db.craftsmanProfile.findUnique({
      where: { id },
      include: { category: true }
    });

    if (!currentProfile) {
      return NextResponse.json({ 
        error: 'Craftsman profile not found' 
      }, { status: 404 });
    }

    // Update user data
    if (name || phone || city || wilaya) {
      await db.user.update({
        where: { id: currentProfile.userId },
        data: {
          ...(name && { name }),
          ...(phone && { phone }),
          ...(city && { city }),
          ...(wilaya && { wilaya }),
        }
      });
    }

    // Update craftsman profile
    const updateData: Record<string, unknown> = {};
    
    if (category) {
      // Find or create category
      let categoryRecord = await db.craftsmenCategory.findFirst({
        where: { id: category }
      });
      
      if (!categoryRecord) {
        categoryRecord = await db.craftsmenCategory.create({
          data: {
            id: category,
            name: category,
            nameAr: category,
            nameFr: category,
          }
        });
      }
      updateData.categoryId = categoryRecord.id;
    }
    
    if (experience !== undefined) updateData.experience = parseInt(experience) || null;
    if (specializations !== undefined) updateData.specializations = JSON.stringify(specializations);
    if (hourlyRate !== undefined) updateData.hourlyRate = parseFloat(hourlyRate) || null;
    if (dailyRate !== undefined) updateData.dailyRate = parseFloat(dailyRate) || null;
    if (isAvailable !== undefined) updateData.isAvailable = isAvailable;
    if (verified !== undefined) updateData.verified = verified;

    const updatedProfile = await db.craftsmanProfile.update({
      where: { id },
      data: updateData,
      include: { category: true }
    });

    // Get updated user data
    const user = await db.user.findUnique({
      where: { id: currentProfile.userId },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatar: true,
        city: true,
        wilaya: true,
      }
    });

    return NextResponse.json({ 
      craftsman: {
        ...updatedProfile,
        user
      }
    });
  } catch (error) {
    console.error('Error updating craftsman:', error);
    return NextResponse.json({ 
      error: 'Failed to update craftsman: ' + (error as Error).message 
    }, { status: 500 });
  }
}

// GET - Get single craftsman profile
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const craftsman = await db.craftsmanProfile.findUnique({
      where: { id },
      include: { category: true }
    });

    if (!craftsman) {
      return NextResponse.json({ 
        error: 'Craftsman not found' 
      }, { status: 404 });
    }

    const user = await db.user.findUnique({
      where: { id: craftsman.userId },
      select: {
        id: true,
        name: true,
        email: true,
        phone: true,
        avatar: true,
        city: true,
        wilaya: true,
      }
    });

    return NextResponse.json({ 
      craftsman: {
        ...craftsman,
        user
      }
    });
  } catch (error) {
    console.error('Error fetching craftsman:', error);
    return NextResponse.json({ 
      error: 'Failed to fetch craftsman' 
    }, { status: 500 });
  }
}
