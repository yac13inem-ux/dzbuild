import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch all craftsmen profiles for admin
export async function GET() {
  try {
    const craftsmen = await db.craftsmanProfile.findMany({
      include: {
        category: true,
      },
      orderBy: { createdAt: 'desc' },
    });
    
    // Get user data for each craftsman
    const craftsmenWithUsers = await Promise.all(
      craftsmen.map(async (craftsman) => {
        const user = await db.user.findUnique({
          where: { id: craftsman.userId },
          select: {
            id: true,
            name: true,
            email: true,
            phone: true,
            avatar: true,
            city: true,
            wilaya: true,
          },
        });
        return {
          ...craftsman,
          user,
        };
      })
    );
    
    return NextResponse.json({ craftsmen: craftsmenWithUsers });
  } catch (error) {
    console.error('Error fetching craftsmen:', error);
    return NextResponse.json({ craftsmen: [] }, { status: 500 });
  }
}

// POST - Create a new craftsman (admin adds directly)
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const {
      name,
      email,
      phone,
      category,
      city,
      wilaya,
      experience,
      specializations,
      hourlyRate,
      dailyRate,
      isAvailable,
      verified,
    } = body;

    // Validate required fields
    if (!name || !category) {
      return NextResponse.json({ 
        error: 'Name and category are required' 
      }, { status: 400 });
    }

    // Find or create category
    let categoryRecord = await db.craftsmenCategory.findFirst({
      where: { id: category }
    });

    if (!categoryRecord) {
      // Create category if it doesn't exist
      categoryRecord = await db.craftsmenCategory.create({
        data: {
          id: category,
          name: category,
          nameAr: category,
          nameFr: category,
        }
      });
    }

    // Check if email already exists
    let user;
    if (email) {
      user = await db.user.findUnique({
        where: { email }
      });
    }

    if (user) {
      // Update existing user to be a craftsman
      user = await db.user.update({
        where: { id: user.id },
        data: {
          role: 'CRAFTSMAN',
          name,
          phone: phone || user.phone,
          city: city || user.city,
          wilaya: wilaya || user.wilaya,
        }
      });
    } else {
      // Create new user with CRAFTSMAN role
      const randomEmail = email || `craftsman_${Date.now()}@dzbuild.dz`;
      user = await db.user.create({
        data: {
          email: randomEmail,
          password: '$2a$10$dummyHashForAdminCreatedUsers', // Dummy password
          name,
          phone,
          city,
          wilaya,
          role: 'CRAFTSMAN',
          isVerified: true,
          isActive: true,
        }
      });
    }

    // Check if craftsman profile already exists for this user
    const existingProfile = await db.craftsmanProfile.findUnique({
      where: { userId: user.id }
    });

    if (existingProfile) {
      return NextResponse.json({ 
        error: 'This user already has a craftsman profile' 
      }, { status: 400 });
    }

    // Create craftsman profile
    const craftsman = await db.craftsmanProfile.create({
      data: {
        userId: user.id,
        categoryId: categoryRecord.id,
        specializations: specializations ? JSON.stringify(specializations) : null,
        experience: experience ? parseInt(experience) : null,
        hourlyRate: hourlyRate ? parseFloat(hourlyRate) : null,
        dailyRate: dailyRate ? parseFloat(dailyRate) : null,
        isAvailable: isAvailable ?? true,
        verified: verified ?? false,
      },
      include: {
        category: true,
      }
    });

    // Return the created craftsman with user data
    return NextResponse.json({ 
      craftsman: {
        ...craftsman,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          city: user.city,
          wilaya: user.wilaya,
        }
      }
    });
  } catch (error) {
    console.error('Error creating craftsman:', error);
    return NextResponse.json({ 
      error: 'Failed to create craftsman: ' + (error as Error).message 
    }, { status: 500 });
  }
}
