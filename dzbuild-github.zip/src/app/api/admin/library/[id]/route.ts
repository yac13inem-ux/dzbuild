import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch single library resource
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const resource = await db.video.findUnique({
      where: { id },
    });
    
    if (!resource) {
      return NextResponse.json({ error: 'Resource not found' }, { status: 404 });
    }
    
    // Increment view count
    await db.video.update({
      where: { id },
      data: { viewCount: { increment: 1 } },
    });
    
    return NextResponse.json({ resource });
  } catch (error) {
    console.error('Error fetching library resource:', error);
    return NextResponse.json({ error: 'Failed to fetch resource' }, { status: 500 });
  }
}

// PUT - Update library resource
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const data = await request.json();
    
    const resource = await db.video.update({
      where: { id },
      data: {
        title: data.title,
        titleAr: data.titleAr || null,
        titleFr: data.titleFr || null,
        description: data.description || null,
        descriptionAr: data.descriptionAr || null,
        descriptionFr: data.descriptionFr || null,
        thumbnail: data.thumbnail || null,
        videoUrl: data.fileUrl || '',
        category: data.category,
        tags: data.tags || null,
        author: data.author || null,
        isFeatured: data.isFeatured || false,
        isPublished: data.isPublished !== false,
      },
    });
    
    return NextResponse.json({ resource });
  } catch (error) {
    console.error('Error updating library resource:', error);
    return NextResponse.json({ error: 'Failed to update resource' }, { status: 500 });
  }
}

// DELETE - Delete library resource
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    console.log('DELETE request for library resource:', id);
    
    const deleted = await db.video.delete({
      where: { id },
    });
    
    console.log('Deleted resource:', deleted.id);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting library resource:', error);
    return NextResponse.json({ error: 'Failed to delete resource: ' + (error as Error).message }, { status: 500 });
  }
}
