import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch all library resources for admin
export async function GET() {
  try {
    const resources = await db.video.findMany({
      orderBy: { createdAt: 'desc' },
    });
    
    return NextResponse.json({ resources });
  } catch (error) {
    console.error('Error fetching library resources:', error);
    return NextResponse.json({ resources: [] }, { status: 500 });
  }
}

// POST - Create new library resource
export async function POST(request: Request) {
  try {
    const data = await request.json();
    console.log('Creating library resource with data:', data);
    console.log('Thumbnail value:', data.thumbnail);
    
    const resource = await db.video.create({
      data: {
        title: data.title || '',
        titleAr: data.titleAr || null,
        titleFr: data.titleFr || null,
        description: data.description || null,
        descriptionAr: data.descriptionAr || null,
        descriptionFr: data.descriptionFr || null,
        thumbnail: data.thumbnail || null,
        videoUrl: data.fileUrl || '',
        source: 'uploaded',
        category: data.category || 'document',
        tags: data.tags || null,
        author: data.author || null,
        isFeatured: data.isFeatured || false,
        isPublished: data.isPublished !== false,
      },
    });
    
    console.log('Created resource:', resource);
    
    return NextResponse.json({ resource });
  } catch (error) {
    console.error('Error creating library resource:', error);
    return NextResponse.json({ error: 'Failed to create resource' }, { status: 500 });
  }
}
