import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ posts: [] });
    }

    const { data, error } = await supabase
      .from('posts')
      .select(`
        id,
        title,
        content,
        post_type,
        status,
        author_id,
        created_at,
        profiles(name)
      `)
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      console.error('Error fetching posts:', error);
      return NextResponse.json({ posts: [] });
    }

    // Transform data to flatten profiles
    const posts = data?.map(post => ({
      ...post,
      profiles: Array.isArray(post.profiles) ? post.profiles[0] : post.profiles,
    })) || [];

    return NextResponse.json({ posts });
  } catch (error) {
    console.error('Admin posts API error:', error);
    return NextResponse.json({ posts: [] });
  }
}
