import { NextRequest, NextResponse } from 'next/server';

// Company types
export const COMPANY_TYPES = {
  BET: { id: 'BET', nameAr: 'مكتب دراسات', nameFr: "Bureau d'Études Techniques", icon: '🏢' },
  CONSTRUCTION: { id: 'CONSTRUCTION', nameAr: 'شركة مقاولات', nameFr: 'Entreprise de Construction', icon: '🏗️' },
  MATERIALS: { id: 'MATERIALS', nameAr: 'شركة مواد البناء', nameFr: 'Fournisseur de Matériaux', icon: '🧱' },
  SURVEY: { id: 'SURVEY', nameAr: 'مكتب مسح طوبوغرافي', nameFr: 'Cabinet de Topographie', icon: '📐' },
  ELECTRICAL_MECHANICAL: { id: 'ELECTRICAL_MECHANICAL', nameAr: 'شركة كهرباء وميكانيك', nameFr: 'Entreprise Électromécanique', icon: '⚡' },
} as const;

// GET - Fetch all companies
export async function GET(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ companies: [] });
    }

    const { searchParams } = new URL(request.url);
    const type = searchParams.get('type');
    const wilaya = searchParams.get('wilaya');
    const city = searchParams.get('city');
    const search = searchParams.get('search');
    const isVerified = searchParams.get('verified');
    const isFeatured = searchParams.get('featured');
    
    let query = supabase
      .from('companies')
      .select('*')
      .eq('is_active', true)
      .order('is_featured', { ascending: false })
      .order('rating', { ascending: false })
      .order('created_at', { ascending: false });

    if (type) {
      query = query.eq('company_type', type);
    }
    
    if (wilaya) {
      query = query.eq('wilaya', wilaya);
    }
    
    if (city) {
      query = query.eq('city', city);
    }
    
    if (search) {
      query = query.or(`name.ilike.%${search}%,description.ilike.%${search}%`);
    }
    
    if (isVerified === 'true') {
      query = query.eq('is_verified', true);
    }
    
    if (isFeatured === 'true') {
      query = query.eq('is_featured', true);
    }

    const { data, error } = await query.limit(100);

    if (error) {
      console.error('Error fetching companies:', error);
      return NextResponse.json({ companies: [] });
    }

    return NextResponse.json({ companies: data || [] });
  } catch (error) {
    console.error('Companies API error:', error);
    return NextResponse.json({ companies: [] });
  }
}

// POST - Create new company
export async function POST(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const {
      name,
      name_fr,
      description,
      description_fr,
      company_type,
      logo_url,
      cover_image_url,
      email,
      phone,
      phone2,
      fax,
      website,
      address,
      city,
      wilaya,
      postal_code,
      latitude,
      longitude,
      registration_number,
      tax_id,
      capital,
      founded_year,
      employee_count_range,
      specialties,
      services,
      certifications,
      owner_id,
      is_featured,
      featured_until,
    } = body;

    if (!name || !company_type) {
      return NextResponse.json({ 
        error: 'Name and company type are required' 
      }, { status: 400 });
    }

    // Validate company type
    const validTypes = Object.keys(COMPANY_TYPES);
    if (!validTypes.includes(company_type)) {
      return NextResponse.json({ 
        error: 'Invalid company type' 
      }, { status: 400 });
    }

    const { data, error } = await supabase
      .from('companies')
      .insert({
        name,
        name_fr,
        description,
        description_fr,
        company_type,
        logo_url,
        cover_image_url,
        email,
        phone,
        phone2,
        fax,
        website,
        address,
        city,
        wilaya,
        postal_code,
        latitude,
        longitude,
        registration_number,
        tax_id,
        capital,
        founded_year,
        employee_count_range,
        specialties: specialties || [],
        services: services || [],
        certifications: certifications || [],
        owner_id,
        is_featured: is_featured || false,
        featured_until,
        is_active: true,
        is_verified: false,
        rating: 0,
        review_count: 0,
        project_count: 0,
        views_count: 0,
        contact_requests_count: 0,
      })
      .select()
      .single();

    if (error) {
      console.error('Error creating company:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, company: data });
  } catch (error) {
    console.error('Create company error:', error);
    return NextResponse.json({ error: 'Failed to create company' }, { status: 500 });
  }
}

// PUT - Update company
export async function PUT(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const body = await request.json();
    const { id, ...updates } = body;

    if (!id) {
      return NextResponse.json({ error: 'Company ID required' }, { status: 400 });
    }

    updates.updated_at = new Date().toISOString();

    const { data, error } = await supabase
      .from('companies')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Error updating company:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true, company: data });
  } catch (error) {
    console.error('Update company error:', error);
    return NextResponse.json({ error: 'Failed to update company' }, { status: 500 });
  }
}

// DELETE - Delete company
export async function DELETE(request: NextRequest) {
  try {
    const { supabase, isSupabaseReady } = await import('@/lib/supabase/client');
    
    if (!isSupabaseReady) {
      return NextResponse.json({ error: 'Database not configured' }, { status: 500 });
    }

    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Company ID required' }, { status: 400 });
    }

    const { error } = await supabase
      .from('companies')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Error deleting company:', error);
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete company error:', error);
    return NextResponse.json({ error: 'Failed to delete company' }, { status: 500 });
  }
}
