import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Check if we have database URL configured
const databaseUrl = process.env.DATABASE_URL

if (!databaseUrl) {
  console.warn('⚠️ DATABASE_URL is not set. Database operations will fail.')
}

// Create Prisma client with optimal settings for Supabase
export const db = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  datasourceUrl: databaseUrl,
})

// In development, store the client in global to prevent
// multiple instances during hot reloading
if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = db
}

// Graceful shutdown
if (process.env.NODE_ENV === 'production') {
  process.on('beforeExit', async () => {
    await db.$disconnect()
  })
}

// Export for convenience
export default db
